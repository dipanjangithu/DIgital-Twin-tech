import { useState, useCallback } from 'react';
import { Wind, Gauge, Thermometer, Droplets, Activity } from 'lucide-react';
import { Header } from './components/Header';
import { MetricCard } from './components/MetricCard';
import { RealTimeChart } from './components/RealTimeChart';
import { DigitalTwinViewer } from './components/DigitalTwinViewer';
import { FilterStatusPanel } from './components/FilterStatusPanel';
import { PredictiveAnalytics } from './components/PredictiveAnalytics';
import { AnomalyPanel } from './components/AnomalyPanel';
import { SimulationControl } from './components/SimulationControl';
import { SystemArchitecture } from './components/SystemArchitecture';
import { EnvironmentPanel } from './components/EnvironmentPanel';
import { PerformanceMetrics } from './components/PerformanceMetrics';
import { MaintenanceTimeline } from './components/MaintenanceTimeline';
import { useSensorData } from './hooks/useSensorData';
import type { ScenarioType } from './types';

function App() {
  const [scenario, setScenario] = useState<ScenarioType>('normal');
  const [selectedFilter, setSelectedFilter] = useState<string | null>(null);
  const [isSimulationRunning, setIsSimulationRunning] = useState(true);
  const [alertCount, setAlertCount] = useState(0);
  const [activeTab, setActiveTab] = useState<'overview' | 'analytics' | 'simulation' | 'architecture'>('overview');
  
  const { systemState, timeSeriesData, resetFilters } = useSensorData(scenario);

  const handleAnomalyCount = useCallback((count: number) => {
    setAlertCount(count);
  }, []);

  if (!systemState) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-full border-4 border-cyan-500/30 border-t-cyan-500 animate-spin" />
          <p className="text-slate-400">Initializing Digital Twin...</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'overview', label: 'Live Overview', icon: Activity },
    { id: 'analytics', label: 'AI Analytics', icon: Activity },
    { id: 'simulation', label: 'Simulation', icon: Wind },
    { id: 'architecture', label: 'Architecture', icon: Gauge }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800">
      <Header 
        systemHealth={systemState.systemHealth}
        operatingMode={systemState.operatingMode}
        alertCount={alertCount}
      />

      {/* Tab Navigation */}
      <div className="px-6 py-4 border-b border-slate-700/50">
        <div className="flex items-center gap-2">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as 'overview' | 'analytics' | 'simulation' | 'architecture')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <main className="p-6">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Key Metrics Row */}
            <div className="grid grid-cols-5 gap-4">
              <MetricCard
                label="Airflow Rate"
                value={systemState.airflow.value}
                unit="m³/s"
                trend={systemState.airflow.value > 8 ? 'up' : 'down'}
                trendValue={(systemState.airflow.value - 8.5) / 8.5 * 100}
                status={systemState.airflow.quality === 'good' ? 'good' : 'warning'}
                icon={<Wind className="w-4 h-4" />}
                sparklineData={timeSeriesData.airflow.map(d => d.value)}
              />
              <MetricCard
                label="Pressure Drop"
                value={systemState.pressure.differential}
                unit="Pa"
                trend={systemState.pressure.differential > 300 ? 'up' : 'stable'}
                trendValue={(systemState.pressure.differential - 250) / 250 * 100}
                status={systemState.pressure.differential > 400 ? 'critical' : systemState.pressure.differential > 300 ? 'warning' : 'good'}
                icon={<Gauge className="w-4 h-4" />}
                sparklineData={timeSeriesData.pressure.map(d => d.value)}
              />
              <MetricCard
                label="Particulates"
                value={(systemState.particulates.totalCount / 1000).toFixed(1)}
                unit="k/m³"
                trend={systemState.particulates.totalCount > 20000 ? 'up' : 'stable'}
                trendValue={(systemState.particulates.totalCount - 15000) / 15000 * 100}
                status={systemState.particulates.totalCount > 50000 ? 'critical' : systemState.particulates.totalCount > 25000 ? 'warning' : 'good'}
                icon={<Activity className="w-4 h-4" />}
                sparklineData={timeSeriesData.particulates.map(d => d.value)}
              />
              <MetricCard
                label="Temperature"
                value={systemState.environment.temperature}
                unit="°C"
                trend="stable"
                trendValue={0}
                status="good"
                icon={<Thermometer className="w-4 h-4" />}
                sparklineData={timeSeriesData.temperature.map(d => d.value)}
              />
              <MetricCard
                label="Humidity"
                value={systemState.environment.humidity}
                unit="%"
                trend="stable"
                trendValue={0}
                status={systemState.environment.humidity > 70 || systemState.environment.humidity < 20 ? 'warning' : 'good'}
                icon={<Droplets className="w-4 h-4" />}
                sparklineData={timeSeriesData.humidity.map(d => d.value)}
              />
            </div>

            {/* Main Content Grid */}
            <div className="grid grid-cols-12 gap-6">
              {/* Digital Twin Viewer - Large */}
              <div className="col-span-8">
                <DigitalTwinViewer
                  filters={systemState.filters}
                  airflow={systemState.airflow}
                  selectedFilter={selectedFilter}
                  onSelectFilter={setSelectedFilter}
                />
              </div>

              {/* Filter Status Panel */}
              <div className="col-span-4">
                <FilterStatusPanel
                  filters={systemState.filters}
                  onSelectFilter={setSelectedFilter}
                  selectedFilter={selectedFilter}
                />
              </div>
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-3 gap-6">
              <RealTimeChart
                data={timeSeriesData.airflow}
                title="Airflow Velocity"
                color="#22d3ee"
                unit="m³/s"
                warningThreshold={10}
                criticalThreshold={12}
                showPrediction={true}
              />
              <RealTimeChart
                data={timeSeriesData.pressure}
                title="Pressure Drop"
                color="#a78bfa"
                unit="Pa"
                warningThreshold={350}
                criticalThreshold={450}
                showPrediction={true}
              />
              <RealTimeChart
                data={timeSeriesData.particulates}
                title="Particulate Concentration"
                color="#f59e0b"
                unit="particles/m³"
                warningThreshold={30000}
                criticalThreshold={50000}
              />
            </div>

            {/* Bottom Row */}
            <div className="grid grid-cols-2 gap-6">
              <AnomalyPanel 
                filters={systemState.filters}
                onAnomalyCount={handleAnomalyCount}
              />
              <EnvironmentPanel
                environment={systemState.environment}
                airflow={systemState.airflow}
                pressure={systemState.pressure}
              />
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <div className="grid grid-cols-12 gap-6">
              <div className="col-span-8">
                <PredictiveAnalytics filters={systemState.filters} />
              </div>
              <div className="col-span-4">
                <FilterStatusPanel
                  filters={systemState.filters}
                  onSelectFilter={setSelectedFilter}
                  selectedFilter={selectedFilter}
                />
              </div>
            </div>
            <div className="grid grid-cols-12 gap-6">
              <div className="col-span-6">
                <PerformanceMetrics 
                  filters={systemState.filters}
                  systemHealth={systemState.systemHealth}
                />
              </div>
              <div className="col-span-6">
                <MaintenanceTimeline filters={systemState.filters} />
              </div>
            </div>
            <div className="grid grid-cols-12 gap-6">
              <div className="col-span-12">
                <AnomalyPanel 
                  filters={systemState.filters}
                  onAnomalyCount={handleAnomalyCount}
                />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'simulation' && (
          <div className="grid grid-cols-12 gap-6">
            <div className="col-span-4">
              <SimulationControl
                currentScenario={scenario}
                onScenarioChange={setScenario}
                onReset={resetFilters}
                isRunning={isSimulationRunning}
                onToggleRunning={() => setIsSimulationRunning(!isSimulationRunning)}
              />
            </div>
            <div className="col-span-8 space-y-6">
              <DigitalTwinViewer
                filters={systemState.filters}
                airflow={systemState.airflow}
                selectedFilter={selectedFilter}
                onSelectFilter={setSelectedFilter}
              />
              <div className="grid grid-cols-2 gap-6">
                <RealTimeChart
                  data={timeSeriesData.pressure}
                  title="Simulated Pressure Drop"
                  color="#ef4444"
                  unit="Pa"
                  warningThreshold={350}
                  criticalThreshold={450}
                  showPrediction={true}
                  height={180}
                />
                <RealTimeChart
                  data={timeSeriesData.particulates}
                  title="Simulated Particulate Load"
                  color="#f59e0b"
                  unit="particles/m³"
                  warningThreshold={30000}
                  criticalThreshold={50000}
                  height={180}
                />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'architecture' && (
          <div className="grid grid-cols-12 gap-6">
            <div className="col-span-8">
              <SystemArchitecture />
            </div>
            <div className="col-span-4 space-y-6">
              <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6">
                <h3 className="text-white font-semibold mb-4">Tech Stack</h3>
                <div className="space-y-3">
                  {[
                    { category: 'Backend', items: ['Python (FastAPI)', 'AsyncIO', 'gRPC'] },
                    { category: 'Streaming', items: ['Apache Kafka', 'Avro/Protobuf'] },
                    { category: 'Database', items: ['InfluxDB', 'PostgreSQL', 'Redis'] },
                    { category: 'ML/AI', items: ['PyTorch', 'LSTM/TFT', 'Isolation Forest', 'SHAP'] },
                    { category: 'Simulation', items: ['NumPy', 'SciPy', 'Kalman Filter'] },
                    { category: 'Frontend', items: ['React', 'TypeScript', 'Recharts', 'WebSocket'] },
                    { category: 'Infrastructure', items: ['Docker', 'Kubernetes', 'Prometheus'] }
                  ].map((stack) => (
                    <div key={stack.category} className="bg-slate-900/50 rounded-lg p-3 border border-slate-700/50">
                      <div className="text-cyan-400 text-xs font-medium mb-2">{stack.category}</div>
                      <div className="flex flex-wrap gap-1.5">
                        {stack.items.map((item) => (
                          <span key={item} className="px-2 py-0.5 bg-slate-800/80 rounded text-slate-300 text-xs">
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6">
                <h3 className="text-white font-semibold mb-4">Security Features</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="text-slate-300">Role-Based Access Control (RBAC)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="text-slate-300">End-to-End Encryption</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="text-slate-300">Fault-Tolerant Pipelines</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="text-slate-300">Audit Logging</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="px-6 py-4 border-t border-slate-700/50">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-4">
            <span>AeroTwin v2.0.0</span>
            <span>•</span>
            <span>Aircraft: A320-200 (REG: N12345)</span>
            <span>•</span>
            <span>System ID: AFDS-2024-001</span>
          </div>
          <div className="flex items-center gap-4">
            <span>Data Retention: 90 days</span>
            <span>•</span>
            <span>Last Sync: {new Date().toLocaleTimeString()}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
