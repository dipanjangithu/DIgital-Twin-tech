import { motion } from 'framer-motion';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer,
  Tooltip
} from 'recharts';
import { TrendingUp, TrendingDown, Minus, Zap } from 'lucide-react';
import type { FilterState } from '../types';

interface PerformanceMetricsProps {
  filters: FilterState[];
  systemHealth: number;
}

export function PerformanceMetrics({ filters, systemHealth }: PerformanceMetricsProps) {
  // Calculate aggregate metrics
  const avgEfficiency = filters.reduce((sum, f) => sum + f.efficiency, 0) / filters.length;
  const avgRUL = filters.reduce((sum, f) => sum + f.remainingLife, 0) / filters.length;
  const totalOperatingHours = filters.reduce((sum, f) => sum + f.operatingHours, 0);
  const avgPressureDrop = filters.reduce((sum, f) => sum + f.pressureDrop, 0) / filters.length;

  const statusDistribution = [
    { name: 'Healthy', value: filters.filter(f => f.status === 'healthy').length, color: '#10b981' },
    { name: 'Warning', value: filters.filter(f => f.status === 'warning').length, color: '#f59e0b' },
    { name: 'Critical', value: filters.filter(f => f.status === 'critical').length, color: '#ef4444' },
    { name: 'Failed', value: filters.filter(f => f.status === 'failed').length, color: '#7f1d1d' }
  ].filter(item => item.value > 0);

  const kpis = [
    {
      label: 'Overall Efficiency',
      value: (avgEfficiency * 100).toFixed(2),
      unit: '%',
      target: 99.9,
      trend: avgEfficiency > 0.99 ? 'up' : avgEfficiency > 0.95 ? 'stable' : 'down'
    },
    {
      label: 'Mean RUL',
      value: avgRUL.toFixed(1),
      unit: '%',
      target: 50,
      trend: avgRUL > 50 ? 'up' : avgRUL > 30 ? 'stable' : 'down'
    },
    {
      label: 'Total Op. Hours',
      value: (totalOperatingHours / 1000).toFixed(1),
      unit: 'kh',
      target: 25,
      trend: 'stable'
    },
    {
      label: 'Avg Pressure Drop',
      value: avgPressureDrop.toFixed(0),
      unit: 'Pa',
      target: 300,
      trend: avgPressureDrop < 250 ? 'up' : avgPressureDrop < 350 ? 'stable' : 'down'
    }
  ];

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-emerald-400" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-400" />;
      default: return <Minus className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-semibold">Performance Metrics</h3>
            <p className="text-slate-400 text-xs">System-wide KPIs</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* System Health Gauge */}
        <div className="flex flex-col items-center">
          <div className="relative w-40 h-40">
            <ResponsiveContainer>
              <PieChart>
                <Pie
                  data={[
                    { value: systemHealth },
                    { value: 100 - systemHealth }
                  ]}
                  cx="50%"
                  cy="50%"
                  startAngle={180}
                  endAngle={0}
                  innerRadius="70%"
                  outerRadius="90%"
                  dataKey="value"
                  stroke="none"
                >
                  <Cell fill={systemHealth >= 70 ? '#10b981' : systemHealth >= 40 ? '#f59e0b' : '#ef4444'} />
                  <Cell fill="#334155" />
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-3xl font-bold ${
                systemHealth >= 70 ? 'text-emerald-400' : 
                systemHealth >= 40 ? 'text-amber-400' : 'text-red-400'
              }`}>
                {systemHealth.toFixed(0)}%
              </span>
              <span className="text-slate-400 text-xs">System Health</span>
            </div>
          </div>
        </div>

        {/* Status Distribution */}
        <div className="flex flex-col items-center">
          <div className="relative w-40 h-40">
            <ResponsiveContainer>
              <PieChart>
                <Pie
                  data={statusDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius="50%"
                  outerRadius="80%"
                  dataKey="value"
                  stroke="#1e293b"
                  strokeWidth={2}
                >
                  {statusDistribution.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-800/95 border border-slate-700 rounded-lg px-3 py-2">
                          <p className="text-white text-sm">{data.name}: {data.value}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold text-white">{filters.length}</span>
              <span className="text-slate-400 text-xs">Filters</span>
            </div>
          </div>
          <div className="flex gap-3 mt-2">
            {statusDistribution.map(item => (
              <div key={item.name} className="flex items-center gap-1 text-xs">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-slate-400">{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-4 gap-3 mt-6">
        {kpis.map((kpi, index) => (
          <motion.div
            key={kpi.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-slate-900/50 rounded-lg p-3 border border-slate-700/50"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-slate-400 text-xs">{kpi.label}</span>
              {getTrendIcon(kpi.trend)}
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-white text-lg font-bold">{kpi.value}</span>
              <span className="text-slate-500 text-xs">{kpi.unit}</span>
            </div>
            <div className="mt-2 h-1 bg-slate-700 rounded-full overflow-hidden">
              <div 
                className={`h-full rounded-full ${
                  kpi.trend === 'up' ? 'bg-emerald-500' :
                  kpi.trend === 'down' ? 'bg-red-500' : 'bg-cyan-500'
                }`}
                style={{ 
                  width: `${Math.min(100, (parseFloat(kpi.value) / kpi.target) * 100)}%` 
                }}
              />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
