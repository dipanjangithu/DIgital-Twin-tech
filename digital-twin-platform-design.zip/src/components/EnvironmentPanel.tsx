import { motion } from 'framer-motion';
import { Thermometer, Droplets, Mountain, Gauge, Wind } from 'lucide-react';
import type { EnvironmentalData, AirflowData, PressureData } from '../types';

interface EnvironmentPanelProps {
  environment: EnvironmentalData;
  airflow: AirflowData;
  pressure: PressureData;
}

export function EnvironmentPanel({ environment, airflow, pressure }: EnvironmentPanelProps) {
  const metrics = [
    {
      icon: Thermometer,
      label: 'Temperature',
      value: environment.temperature,
      unit: '°C',
      color: environment.temperature > 30 ? 'text-red-400' : environment.temperature < 0 ? 'text-cyan-400' : 'text-emerald-400',
      range: { min: -70, max: 60 },
      zones: [
        { start: 0, end: 20, color: 'bg-cyan-500/30' },
        { start: 20, end: 60, color: 'bg-emerald-500/30' },
        { start: 60, end: 100, color: 'bg-red-500/30' }
      ]
    },
    {
      icon: Droplets,
      label: 'Humidity',
      value: environment.humidity,
      unit: '%',
      color: environment.humidity > 70 ? 'text-amber-400' : environment.humidity < 20 ? 'text-amber-400' : 'text-emerald-400',
      range: { min: 0, max: 100 }
    },
    {
      icon: Mountain,
      label: 'Altitude',
      value: environment.altitude,
      unit: 'ft',
      color: 'text-blue-400',
      range: { min: 0, max: 45000 },
      format: (v: number) => v.toLocaleString()
    },
    {
      icon: Gauge,
      label: 'Ambient Pressure',
      value: environment.ambientPressure,
      unit: 'kPa',
      color: 'text-purple-400',
      range: { min: 20, max: 102 }
    },
    {
      icon: Wind,
      label: 'Airflow Velocity',
      value: airflow.velocity,
      unit: 'm/s',
      color: 'text-cyan-400',
      range: { min: 0, max: 25 }
    },
    {
      icon: Gauge,
      label: 'Pressure Drop',
      value: pressure.differential,
      unit: 'Pa',
      color: pressure.differential > 400 ? 'text-red-400' : pressure.differential > 300 ? 'text-amber-400' : 'text-emerald-400',
      range: { min: 0, max: 500 }
    }
  ];

  const getPercentage = (value: number, range: { min: number; max: number }) => {
    return Math.max(0, Math.min(100, ((value - range.min) / (range.max - range.min)) * 100));
  };

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-4">
      <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
        <Wind className="w-5 h-5 text-cyan-400" />
        Environmental Conditions
      </h3>

      <div className="grid grid-cols-2 gap-3">
        {metrics.map((metric, index) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            className="bg-slate-900/50 rounded-lg p-3 border border-slate-700/50"
          >
            <div className="flex items-center gap-2 mb-2">
              <metric.icon className={`w-4 h-4 ${metric.color}`} />
              <span className="text-slate-400 text-xs">{metric.label}</span>
            </div>
            
            <div className="flex items-baseline gap-1 mb-2">
              <span className={`text-xl font-bold ${metric.color}`}>
                {metric.format ? metric.format(metric.value) : metric.value.toFixed(1)}
              </span>
              <span className="text-slate-500 text-xs">{metric.unit}</span>
            </div>
            
            {/* Progress bar */}
            <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
              <motion.div
                className={`h-full rounded-full ${
                  metric.color.includes('red') ? 'bg-red-500' :
                  metric.color.includes('amber') ? 'bg-amber-500' :
                  metric.color.includes('cyan') ? 'bg-cyan-500' :
                  metric.color.includes('purple') ? 'bg-purple-500' :
                  metric.color.includes('blue') ? 'bg-blue-500' :
                  'bg-emerald-500'
                }`}
                initial={{ width: 0 }}
                animate={{ width: `${getPercentage(metric.value, metric.range)}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Altitude visualization */}
      <div className="mt-4 bg-slate-900/50 rounded-lg p-4 border border-slate-700/50">
        <div className="flex items-center justify-between mb-3">
          <span className="text-slate-400 text-sm">Flight Profile</span>
          <span className="text-white font-mono text-sm">{environment.altitude.toLocaleString()} ft</span>
        </div>
        
        <div className="relative h-20">
          {/* Altitude bands */}
          <div className="absolute inset-0 flex flex-col">
            <div className="flex-1 bg-gradient-to-r from-slate-800/50 to-slate-700/30 border-b border-slate-700/50">
              <span className="text-xs text-slate-500 ml-2">40,000+</span>
            </div>
            <div className="flex-1 bg-gradient-to-r from-blue-900/20 to-blue-800/10 border-b border-slate-700/50">
              <span className="text-xs text-slate-500 ml-2">30,000</span>
            </div>
            <div className="flex-1 bg-gradient-to-r from-cyan-900/20 to-cyan-800/10 border-b border-slate-700/50">
              <span className="text-xs text-slate-500 ml-2">20,000</span>
            </div>
            <div className="flex-1 bg-gradient-to-r from-emerald-900/20 to-emerald-800/10">
              <span className="text-xs text-slate-500 ml-2">Ground</span>
            </div>
          </div>
          
          {/* Aircraft indicator */}
          <motion.div
            className="absolute left-1/2 transform -translate-x-1/2"
            animate={{ 
              top: `${100 - (environment.altitude / 45000) * 100}%`
            }}
            transition={{ type: 'spring', stiffness: 100 }}
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-cyan-500/20 border-2 border-cyan-400 flex items-center justify-center">
                <span className="text-lg">✈️</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
