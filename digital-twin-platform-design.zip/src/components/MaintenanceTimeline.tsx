import { motion } from 'framer-motion';
import { Calendar, Clock, Wrench, AlertTriangle, CheckCircle2 } from 'lucide-react';
import type { FilterState } from '../types';

interface MaintenanceTimelineProps {
  filters: FilterState[];
}

export function MaintenanceTimeline({ filters }: MaintenanceTimelineProps) {
  // Sort filters by next maintenance date
  const sortedFilters = [...filters].sort((a, b) => 
    a.nextMaintenanceDate - b.nextMaintenanceDate
  );

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  const getDaysUntil = (timestamp: number) => {
    const days = Math.ceil((timestamp - Date.now()) / (1000 * 60 * 60 * 24));
    return days;
  };

  const getUrgencyColor = (days: number) => {
    if (days <= 2) return 'border-red-500 bg-red-500/10';
    if (days <= 7) return 'border-amber-500 bg-amber-500/10';
    if (days <= 14) return 'border-yellow-500 bg-yellow-500/10';
    return 'border-emerald-500 bg-emerald-500/10';
  };

  const getUrgencyLabel = (days: number) => {
    if (days <= 0) return { text: 'Overdue', color: 'text-red-400' };
    if (days <= 2) return { text: 'Urgent', color: 'text-red-400' };
    if (days <= 7) return { text: 'Soon', color: 'text-amber-400' };
    if (days <= 14) return { text: 'Scheduled', color: 'text-yellow-400' };
    return { text: 'Planned', color: 'text-emerald-400' };
  };

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center">
            <Calendar className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-semibold">Maintenance Timeline</h3>
            <p className="text-slate-400 text-xs">Upcoming scheduled maintenance</p>
          </div>
        </div>
      </div>

      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gradient-to-b from-slate-600 via-slate-700 to-transparent" />

        <div className="space-y-4">
          {sortedFilters.map((filter, index) => {
            const daysUntil = getDaysUntil(filter.nextMaintenanceDate);
            const urgency = getUrgencyLabel(daysUntil);
            
            return (
              <motion.div
                key={filter.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative pl-10"
              >
                {/* Timeline dot */}
                <div className={`absolute left-2 top-3 w-4 h-4 rounded-full border-2 ${getUrgencyColor(daysUntil)}`}>
                  <div className={`w-2 h-2 rounded-full absolute top-0.5 left-0.5 ${
                    daysUntil <= 2 ? 'bg-red-400' :
                    daysUntil <= 7 ? 'bg-amber-400' :
                    daysUntil <= 14 ? 'bg-yellow-400' : 'bg-emerald-400'
                  }`} />
                </div>

                <div className={`p-4 rounded-lg border ${getUrgencyColor(daysUntil)}`}>
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-white font-medium text-sm">{filter.name}</h4>
                        <span className={`px-2 py-0.5 rounded text-xs font-medium ${urgency.color} bg-slate-800/50`}>
                          {urgency.text}
                        </span>
                      </div>
                      <p className="text-slate-400 text-xs mt-0.5">{filter.location}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-white font-mono text-sm">{formatDate(filter.nextMaintenanceDate)}</div>
                      <div className={`text-xs ${urgency.color}`}>
                        {daysUntil <= 0 ? 'Overdue!' : `${daysUntil} day${daysUntil !== 1 ? 's' : ''}`}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs mt-3">
                    <div className="flex items-center gap-1.5 text-slate-400">
                      <Wrench className="w-3 h-3" />
                      <span>
                        {filter.status === 'critical' ? 'Replace' : 
                         filter.status === 'warning' ? 'Inspect' : 'Routine'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-400">
                      <Clock className="w-3 h-3" />
                      <span>Est. 45 min</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-400">
                      {filter.remainingLife < 30 ? (
                        <AlertTriangle className="w-3 h-3 text-amber-400" />
                      ) : (
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      )}
                      <span>RUL: {filter.remainingLife.toFixed(0)}%</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Summary */}
      <div className="mt-6 pt-4 border-t border-slate-700/50 grid grid-cols-3 gap-4 text-center">
        <div>
          <div className="text-red-400 font-bold text-lg">
            {sortedFilters.filter(f => getDaysUntil(f.nextMaintenanceDate) <= 7).length}
          </div>
          <div className="text-slate-400 text-xs">This Week</div>
        </div>
        <div>
          <div className="text-amber-400 font-bold text-lg">
            {sortedFilters.filter(f => {
              const days = getDaysUntil(f.nextMaintenanceDate);
              return days > 7 && days <= 30;
            }).length}
          </div>
          <div className="text-slate-400 text-xs">This Month</div>
        </div>
        <div>
          <div className="text-emerald-400 font-bold text-lg">
            {sortedFilters.filter(f => getDaysUntil(f.nextMaintenanceDate) > 30).length}
          </div>
          <div className="text-slate-400 text-xs">Later</div>
        </div>
      </div>
    </div>
  );
}
