import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, 
  TrendingUp, 
  AlertCircle, 
  Wrench, 
  DollarSign, 
  Clock,
  ChevronRight,
  BarChart3,
  Lightbulb
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import type { FilterState, Prediction, MaintenanceRecommendation } from '../types';
import { 
  predictRemainingUsefulLife, 
  generateMaintenanceRecommendations,
  optimizeMaintenanceSchedule,
  classifyFailureRisk
} from '../utils/mlModels';

interface PredictiveAnalyticsProps {
  filters: FilterState[];
}

export function PredictiveAnalytics({ filters }: PredictiveAnalyticsProps) {
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [recommendations, setRecommendations] = useState<MaintenanceRecommendation[]>([]);
  const [selectedTab, setSelectedTab] = useState<'rul' | 'recommendations' | 'optimization'>('rul');
  const [optimizationStats, setOptimizationStats] = useState<ReturnType<typeof optimizeMaintenanceSchedule> | null>(null);

  useEffect(() => {
    // Generate predictions for all filters
    const newPredictions = filters.map(filter => predictRemainingUsefulLife(filter));
    setPredictions(newPredictions);

    // Generate maintenance recommendations
    const newRecommendations = generateMaintenanceRecommendations(filters);
    setRecommendations(newRecommendations);

    // Calculate optimization stats
    const stats = optimizeMaintenanceSchedule(newRecommendations);
    setOptimizationStats(stats);
  }, [filters]);

  const getPriorityColor = (priority: MaintenanceRecommendation['priority']) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'high': return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      case 'medium': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'low': return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  const rulChartData = filters.map(filter => {
    const prediction = predictions.find(p => p.filterId === filter.id);
    const risk = classifyFailureRisk(filter);
    return {
      name: filter.name.replace('Filter - ', '').substring(0, 10),
      rul: prediction?.value || filter.remainingLife,
      failureRisk: risk.failureProb,
      confidence: (prediction?.confidence || 0.8) * 100
    };
  });

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-semibold">AI Predictive Analytics</h3>
            <p className="text-slate-400 text-xs">ML-powered insights & recommendations</p>
          </div>
        </div>
        <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-purple-500/20 border border-purple-500/30">
          <div className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
          <span className="text-purple-400 text-xs">Models Active</span>
        </div>
      </div>

      {/* Tab navigation */}
      <div className="flex gap-2 mb-6">
        {[
          { id: 'rul', label: 'RUL Prediction', icon: TrendingUp },
          { id: 'recommendations', label: 'Maintenance', icon: Wrench },
          { id: 'optimization', label: 'Cost Optimization', icon: DollarSign }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setSelectedTab(tab.id as 'rul' | 'recommendations' | 'optimization')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedTab === tab.id
                ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {selectedTab === 'rul' && (
          <motion.div
            key="rul"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <div className="h-64 mb-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={rulChartData} layout="vertical" margin={{ left: 20, right: 20 }}>
                  <XAxis type="number" domain={[0, 100]} stroke="#64748b" tick={{ fill: '#64748b', fontSize: 10 }} />
                  <YAxis type="category" dataKey="name" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 11 }} width={80} />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-slate-800/95 backdrop-blur-sm border border-slate-700 rounded-lg p-3 shadow-xl">
                            <p className="text-white font-medium mb-2">{data.name}</p>
                            <p className="text-emerald-400 text-sm">RUL: {data.rul.toFixed(1)}%</p>
                            <p className="text-red-400 text-sm">Failure Risk: {data.failureRisk.toFixed(1)}%</p>
                            <p className="text-slate-400 text-sm">Confidence: {data.confidence.toFixed(1)}%</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="rul" radius={[0, 4, 4, 0]}>
                    {rulChartData.map((entry, index) => (
                      <Cell 
                        key={index} 
                        fill={entry.rul >= 60 ? '#10b981' : entry.rul >= 30 ? '#f59e0b' : '#ef4444'} 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Feature importance for selected prediction */}
            {predictions[0]?.featureImportance && (
              <div className="bg-slate-900/50 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <BarChart3 className="w-4 h-4 text-purple-400" />
                  <span className="text-white text-sm font-medium">Feature Importance (SHAP)</span>
                </div>
                <div className="space-y-2">
                  {Object.entries(predictions[0].featureImportance).map(([feature, importance]) => (
                    <div key={feature} className="flex items-center gap-3">
                      <span className="text-slate-400 text-xs w-32 truncate">{feature}</span>
                      <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${importance * 100}%` }}
                          transition={{ duration: 0.5 }}
                        />
                      </div>
                      <span className="text-white text-xs w-12 text-right">{(importance * 100).toFixed(0)}%</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {selectedTab === 'recommendations' && (
          <motion.div
            key="recommendations"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-3"
          >
            {recommendations.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                <Lightbulb className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>No maintenance recommendations at this time</p>
              </div>
            ) : (
              recommendations.map((rec, index) => (
                <motion.div
                  key={rec.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-slate-900/50 rounded-lg p-4 border border-slate-700/50 hover:border-slate-600/50 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-xs font-semibold uppercase border ${getPriorityColor(rec.priority)}`}>
                        {rec.priority}
                      </span>
                      <span className="text-slate-400 text-xs capitalize">{rec.type}</span>
                    </div>
                    <span className="text-slate-400 text-xs flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatDate(rec.scheduledDate)}
                    </span>
                  </div>
                  
                  <p className="text-white text-sm mb-3">{rec.reason}</p>
                  
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-4">
                      <span className="text-slate-400">
                        <DollarSign className="w-3 h-3 inline" /> ${rec.estimatedCost}
                      </span>
                      <span className="text-slate-400">
                        <Clock className="w-3 h-3 inline" /> {rec.estimatedDowntime} min
                      </span>
                      <span className="text-slate-400">
                        Confidence: {(rec.confidence * 100).toFixed(0)}%
                      </span>
                    </div>
                    <button className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 transition-colors">
                      Schedule <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                </motion.div>
              ))
            )}
          </motion.div>
        )}

        {selectedTab === 'optimization' && optimizationStats && (
          <motion.div
            key="optimization"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700/50">
                <div className="text-slate-400 text-sm mb-1">Total Maintenance Cost</div>
                <div className="text-2xl font-bold text-white">${optimizationStats.totalCost.toLocaleString()}</div>
                <div className="text-emerald-400 text-xs mt-1">
                  Optimized: ${optimizationStats.optimizedCost.toLocaleString()}
                </div>
              </div>
              <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700/50">
                <div className="text-slate-400 text-sm mb-1">Total Downtime</div>
                <div className="text-2xl font-bold text-white">{optimizationStats.totalDowntime} min</div>
                <div className="text-slate-400 text-xs mt-1">
                  ~{(optimizationStats.totalDowntime / 60).toFixed(1)} hours
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 rounded-lg p-4 border border-emerald-500/20">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <div className="text-emerald-400 font-semibold">Optimization Savings</div>
                  <div className="text-slate-400 text-xs">AI-recommended batching strategy</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-slate-400 text-xs">Cost Savings</div>
                  <div className="text-emerald-400 text-xl font-bold">${optimizationStats.savings}</div>
                </div>
                <div>
                  <div className="text-slate-400 text-xs">Batched Operations</div>
                  <div className="text-emerald-400 text-xl font-bold">{optimizationStats.batchedOperations}</div>
                </div>
              </div>
            </div>

            <div className="mt-4 p-4 bg-slate-900/50 rounded-lg border border-slate-700/50">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-4 h-4 text-cyan-400" />
                <span className="text-white text-sm font-medium">AI Recommendation</span>
              </div>
              <p className="text-slate-300 text-sm">
                Schedule maintenance for filters with warning status together during next planned downtime 
                to reduce labor costs by 15% and minimize aircraft unavailability. Consider replacing the 
                Pre-Filter immediately to prevent cascade failures.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
