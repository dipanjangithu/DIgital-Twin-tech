import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import type { ReactNode } from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  unit: string;
  trend?: 'up' | 'down' | 'stable';
  trendValue?: number;
  status?: 'good' | 'warning' | 'critical';
  icon?: ReactNode;
  sparklineData?: number[];
}

export function MetricCard({ 
  label, 
  value, 
  unit, 
  trend = 'stable', 
  trendValue = 0,
  status = 'good',
  icon,
  sparklineData = []
}: MetricCardProps) {
  const statusColors = {
    good: 'from-emerald-500/10 to-emerald-500/5 border-emerald-500/20',
    warning: 'from-amber-500/10 to-amber-500/5 border-amber-500/20',
    critical: 'from-red-500/10 to-red-500/5 border-red-500/20'
  };

  const statusTextColors = {
    good: 'text-emerald-400',
    warning: 'text-amber-400',
    critical: 'text-red-400'
  };

  const trendColors = {
    up: 'text-emerald-400',
    down: 'text-red-400',
    stable: 'text-slate-400'
  };

  const TrendIcon = trend === 'up' ? TrendingUp : trend === 'down' ? TrendingDown : Minus;

  // Generate sparkline path
  const generateSparkline = () => {
    if (sparklineData.length < 2) return '';
    
    const min = Math.min(...sparklineData);
    const max = Math.max(...sparklineData);
    const range = max - min || 1;
    const width = 80;
    const height = 24;
    
    const points = sparklineData.map((val, i) => {
      const x = (i / (sparklineData.length - 1)) * width;
      const y = height - ((val - min) / range) * height;
      return `${x},${y}`;
    });
    
    return `M${points.join(' L')}`;
  };

  return (
    <div className={`relative overflow-hidden rounded-xl bg-gradient-to-br ${statusColors[status]} border backdrop-blur-sm p-4`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            {icon && <span className={statusTextColors[status]}>{icon}</span>}
            <span className="text-slate-400 text-sm font-medium">{label}</span>
          </div>
          
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold text-white">
              {typeof value === 'number' ? value.toFixed(1) : value}
            </span>
            <span className="text-slate-400 text-sm">{unit}</span>
          </div>
          
          <div className={`flex items-center gap-1 mt-2 text-xs ${trendColors[trend]}`}>
            <TrendIcon className="w-3 h-3" />
            <span>{trendValue > 0 ? '+' : ''}{trendValue.toFixed(1)}%</span>
            <span className="text-slate-500">vs last hour</span>
          </div>
        </div>
        
        {sparklineData.length > 1 && (
          <div className="w-20 h-8 opacity-60">
            <svg viewBox="0 0 80 24" className="w-full h-full">
              <path
                d={generateSparkline()}
                fill="none"
                stroke={status === 'good' ? '#10b981' : status === 'warning' ? '#f59e0b' : '#ef4444'}
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        )}
      </div>
      
      {/* Decorative gradient orb */}
      <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full blur-2xl opacity-20 ${
        status === 'good' ? 'bg-emerald-500' : status === 'warning' ? 'bg-amber-500' : 'bg-red-500'
      }`} />
    </div>
  );
}
