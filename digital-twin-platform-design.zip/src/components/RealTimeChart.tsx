import { 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ReferenceLine,
  Area,
  ComposedChart
} from 'recharts';
import type { TimeSeriesPoint } from '../types';

interface RealTimeChartProps {
  data: TimeSeriesPoint[];
  title: string;
  color: string;
  unit: string;
  warningThreshold?: number;
  criticalThreshold?: number;
  showPrediction?: boolean;
  height?: number;
}

export function RealTimeChart({
  data,
  title,
  color,
  unit,
  warningThreshold,
  criticalThreshold,
  showPrediction = false,
  height = 200
}: RealTimeChartProps) {
  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const CustomTooltip = ({ active, payload, label }: {active?: boolean; payload?: Array<{value: number; dataKey: string}>; label?: number}) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-800/95 backdrop-blur-sm border border-slate-700 rounded-lg p-3 shadow-xl">
          <p className="text-slate-400 text-xs mb-1">{label ? formatTime(label) : ''}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-white font-medium">
              {entry.dataKey === 'value' ? 'Actual' : 'Predicted'}: {entry.value.toFixed(2)} {unit}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  // Add prediction data if enabled
  const chartData = showPrediction ? data.map((point, index) => ({
    ...point,
    predicted: index >= data.length - 10 
      ? point.value * (1 + (Math.random() - 0.5) * 0.1)
      : undefined,
    upperBound: index >= data.length - 10 
      ? point.value * 1.1
      : undefined,
    lowerBound: index >= data.length - 10 
      ? point.value * 0.9
      : undefined
  })) : data;

  const minValue = Math.min(...data.map(d => d.value)) * 0.9;
  const maxValue = Math.max(...data.map(d => d.value)) * 1.1;

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-semibold">{title}</h3>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
            <span className="text-slate-400">Live</span>
          </div>
          {showPrediction && (
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 opacity-50" />
              <span className="text-slate-400">Predicted</span>
            </div>
          )}
        </div>
      </div>
      
      <ResponsiveContainer width="100%" height={height}>
        <ComposedChart data={chartData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
          <defs>
            <linearGradient id={`gradient-${title}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.3} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
            <linearGradient id="predictionGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity={0.2} />
              <stop offset="100%" stopColor="#22d3ee" stopOpacity={0} />
            </linearGradient>
          </defs>
          
          <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
          
          <XAxis 
            dataKey="timestamp" 
            tickFormatter={formatTime}
            stroke="#64748b"
            tick={{ fill: '#64748b', fontSize: 10 }}
            axisLine={{ stroke: '#475569' }}
          />
          
          <YAxis 
            domain={[minValue, maxValue]}
            stroke="#64748b"
            tick={{ fill: '#64748b', fontSize: 10 }}
            axisLine={{ stroke: '#475569' }}
            tickFormatter={(value) => value.toFixed(0)}
          />
          
          <Tooltip content={<CustomTooltip />} />
          
          {warningThreshold && (
            <ReferenceLine 
              y={warningThreshold} 
              stroke="#f59e0b" 
              strokeDasharray="5 5"
              label={{ value: 'Warning', fill: '#f59e0b', fontSize: 10, position: 'right' }}
            />
          )}
          
          {criticalThreshold && (
            <ReferenceLine 
              y={criticalThreshold} 
              stroke="#ef4444" 
              strokeDasharray="5 5"
              label={{ value: 'Critical', fill: '#ef4444', fontSize: 10, position: 'right' }}
            />
          )}
          
          {showPrediction && (
            <Area
              dataKey="upperBound"
              stroke="none"
              fill="url(#predictionGradient)"
              fillOpacity={0.3}
            />
          )}
          
          <Area
            type="monotone"
            dataKey="value"
            stroke={color}
            strokeWidth={2}
            fill={`url(#gradient-${title})`}
            dot={false}
            activeDot={{ r: 4, fill: color, stroke: '#1e293b', strokeWidth: 2 }}
          />
          
          {showPrediction && (
            <Line
              type="monotone"
              dataKey="predicted"
              stroke="#22d3ee"
              strokeWidth={2}
              strokeDasharray="5 5"
              dot={false}
            />
          )}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
