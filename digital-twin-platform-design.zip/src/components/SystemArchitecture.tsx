import { motion } from 'framer-motion';
import { 
  Database, 
  Server, 
  Cpu, 
  Radio, 
  Cloud, 
  Shield, 
  Activity,
  GitBranch,
  Layers
} from 'lucide-react';

export function SystemArchitecture() {
  const architectureLayers = [
    {
      name: 'Data Ingestion',
      icon: Radio,
      color: 'from-cyan-500 to-blue-500',
      services: ['IoT Sensors', 'Kafka Streams', 'Schema Validation', 'Fault-Tolerant Queue'],
      status: 'active'
    },
    {
      name: 'Data Storage',
      icon: Database,
      color: 'from-purple-500 to-indigo-500',
      services: ['InfluxDB (Telemetry)', 'PostgreSQL (Metadata)', 'Time-Series Downsampling'],
      status: 'active'
    },
    {
      name: 'Physics Engine',
      icon: Cpu,
      color: 'from-amber-500 to-orange-500',
      services: ['Darcy Flow Model', 'Particle Dynamics', 'Kalman Filtering', 'CFD Integration'],
      status: 'active'
    },
    {
      name: 'ML Intelligence',
      icon: Activity,
      color: 'from-emerald-500 to-teal-500',
      services: ['LSTM/TFT (RUL)', 'Isolation Forest', 'XGBoost Classifier', 'SHAP Explainer'],
      status: 'active'
    },
    {
      name: 'Microservices',
      icon: GitBranch,
      color: 'from-rose-500 to-pink-500',
      services: ['Ingestion Service', 'Simulation Engine', 'ML Inference', 'Alerting Service'],
      status: 'active'
    },
    {
      name: 'Infrastructure',
      icon: Cloud,
      color: 'from-slate-500 to-slate-600',
      services: ['Docker Containers', 'Kubernetes', 'gRPC/REST APIs', 'WebSocket'],
      status: 'active'
    }
  ];

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-slate-500 to-slate-600 flex items-center justify-center">
            <Layers className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-semibold">System Architecture</h3>
            <p className="text-slate-400 text-xs">Production-grade digital twin stack</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-400" />
          <span className="text-emerald-400 text-xs">All Systems Operational</span>
        </div>
      </div>

      <div className="space-y-3">
        {architectureLayers.map((layer, index) => (
          <motion.div
            key={layer.name}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative"
          >
            <div className="flex items-stretch gap-3">
              {/* Layer icon */}
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${layer.color} flex items-center justify-center flex-shrink-0`}>
                <layer.icon className="w-6 h-6 text-white" />
              </div>
              
              {/* Layer content */}
              <div className="flex-1 bg-slate-900/50 rounded-lg p-3 border border-slate-700/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-medium text-sm">{layer.name}</span>
                  <div className="flex items-center gap-1.5">
                    <motion.div 
                      className="w-2 h-2 rounded-full bg-emerald-400"
                      animate={{ opacity: [1, 0.5, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                    <span className="text-emerald-400 text-xs">Active</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {layer.services.map((service) => (
                    <span 
                      key={service}
                      className="px-2 py-0.5 bg-slate-800/80 rounded text-slate-300 text-xs"
                    >
                      {service}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Connection line to next layer */}
            {index < architectureLayers.length - 1 && (
              <div className="absolute left-6 top-12 w-0.5 h-3 bg-gradient-to-b from-slate-600 to-transparent" />
            )}
          </motion.div>
        ))}
      </div>

      {/* Data flow indicator */}
      <div className="mt-6 pt-4 border-t border-slate-700/50">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <Server className="w-3 h-3 text-slate-400" />
              <span className="text-slate-400">Throughput:</span>
              <span className="text-white font-mono">12.5k msg/s</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Database className="w-3 h-3 text-slate-400" />
              <span className="text-slate-400">Latency:</span>
              <span className="text-emerald-400 font-mono">&lt;15ms</span>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Uptime:</span>
            <span className="text-emerald-400 font-mono">99.97%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
