import { motion } from 'framer-motion';
import type { FilterState, AirflowData } from '../types';

interface DigitalTwinViewerProps {
  filters: FilterState[];
  airflow: AirflowData;
  selectedFilter: string | null;
  onSelectFilter: (id: string | null) => void;
}

export function DigitalTwinViewer({ 
  filters, 
  airflow, 
  selectedFilter, 
  onSelectFilter 
}: DigitalTwinViewerProps) {
  const getStatusColor = (status: FilterState['status']) => {
    switch (status) {
      case 'healthy': return '#10b981';
      case 'warning': return '#f59e0b';
      case 'critical': return '#ef4444';
      case 'failed': return '#7f1d1d';
      default: return '#64748b';
    }
  };

  const getGlowColor = (status: FilterState['status']) => {
    switch (status) {
      case 'healthy': return '0 0 20px rgba(16, 185, 129, 0.5)';
      case 'warning': return '0 0 20px rgba(245, 158, 11, 0.5)';
      case 'critical': return '0 0 20px rgba(239, 68, 68, 0.6), 0 0 40px rgba(239, 68, 68, 0.3)';
      case 'failed': return '0 0 30px rgba(127, 29, 29, 0.8)';
      default: return 'none';
    }
  };

  // Calculate airflow particle positions for animation
  const airflowIntensity = airflow.velocity / 20; // Normalize to 0-1

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6 h-full">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-white font-semibold text-lg">Digital Twin - System Visualization</h3>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span className="text-slate-400">Healthy</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span className="text-slate-400">Warning</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
            <span className="text-slate-400">Critical</span>
          </div>
        </div>
      </div>

      <div className="relative h-80 bg-slate-900/50 rounded-lg overflow-hidden">
        {/* Aircraft cabin outline */}
        <svg viewBox="0 0 800 300" className="w-full h-full">
          <defs>
            <linearGradient id="cabinGradient" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#1e293b" />
              <stop offset="50%" stopColor="#334155" />
              <stop offset="100%" stopColor="#1e293b" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Aircraft fuselage shape */}
          <path
            d="M50 150 Q100 50 200 50 L600 50 Q700 50 750 150 Q700 250 600 250 L200 250 Q100 250 50 150 Z"
            fill="url(#cabinGradient)"
            stroke="#475569"
            strokeWidth="2"
          />

          {/* Airflow direction arrows */}
          <g className="opacity-60">
            {[...Array(8)].map((_, i) => (
              <motion.g
                key={i}
                initial={{ x: -20 }}
                animate={{ x: 760 }}
                transition={{
                  duration: 3 / (airflowIntensity + 0.5),
                  repeat: Infinity,
                  delay: i * 0.4,
                  ease: "linear"
                }}
              >
                <circle
                  cx="0"
                  cy={100 + (i % 3) * 50}
                  r="3"
                  fill="#22d3ee"
                  opacity={0.6}
                />
                <path
                  d={`M-8 ${100 + (i % 3) * 50} L0 ${100 + (i % 3) * 50 - 4} L0 ${100 + (i % 3) * 50 + 4} Z`}
                  fill="#22d3ee"
                  opacity={0.4}
                />
              </motion.g>
            ))}
          </g>

          {/* Bleed air intake */}
          <g>
            <rect x="20" y="120" width="60" height="60" rx="8" fill="#1e293b" stroke="#475569" strokeWidth="2" />
            <text x="50" y="155" textAnchor="middle" fill="#64748b" fontSize="10">BLEED</text>
            <text x="50" y="168" textAnchor="middle" fill="#64748b" fontSize="10">AIR</text>
            
            {/* Animated intake arrows */}
            <motion.path
              d="M10 150 L30 150"
              stroke="#22d3ee"
              strokeWidth="2"
              strokeLinecap="round"
              initial={{ opacity: 0.3 }}
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </g>

          {/* Filter positions in the system */}
          {filters.map((filter, index) => {
            const positions = [
              { x: 150, y: 80, label: 'Forward' },
              { x: 300, y: 150, label: 'Mid' },
              { x: 450, y: 220, label: 'Recirculation' },
              { x: 600, y: 80, label: 'Aft' },
              { x: 100, y: 180, label: 'Pre-filter' }
            ];
            const pos = positions[index] || { x: 200 + index * 100, y: 150, label: '' };
            const isSelected = selectedFilter === filter.id;
            
            return (
              <g key={filter.id} onClick={() => onSelectFilter(isSelected ? null : filter.id)} className="cursor-pointer">
                {/* Filter housing */}
                <motion.rect
                  x={pos.x - 35}
                  y={pos.y - 25}
                  width="70"
                  height="50"
                  rx="6"
                  fill={isSelected ? '#1e3a5f' : '#1e293b'}
                  stroke={getStatusColor(filter.status)}
                  strokeWidth={isSelected ? 3 : 2}
                  initial={{ scale: 1 }}
                  animate={{ 
                    scale: isSelected ? 1.05 : 1,
                    boxShadow: getGlowColor(filter.status)
                  }}
                  style={{ filter: filter.status === 'critical' ? 'url(#glow)' : 'none' }}
                  whileHover={{ scale: 1.08 }}
                />
                
                {/* Filter media lines */}
                {[...Array(5)].map((_, i) => (
                  <line
                    key={i}
                    x1={pos.x - 25}
                    y1={pos.y - 15 + i * 8}
                    x2={pos.x + 25}
                    y2={pos.y - 15 + i * 8}
                    stroke={getStatusColor(filter.status)}
                    strokeWidth="2"
                    opacity={1 - (filter.particleLoadingPct / 100) * 0.7}
                  />
                ))}
                
                {/* Filter label */}
                <text x={pos.x} y={pos.y + 40} textAnchor="middle" fill="#94a3b8" fontSize="10">
                  {filter.type}
                </text>
                
                {/* Status indicator */}
                <motion.circle
                  cx={pos.x + 30}
                  cy={pos.y - 20}
                  r="5"
                  fill={getStatusColor(filter.status)}
                  animate={filter.status === 'critical' ? { 
                    scale: [1, 1.3, 1],
                    opacity: [1, 0.7, 1]
                  } : {}}
                  transition={{ duration: 0.8, repeat: Infinity }}
                />
                
                {/* Remaining life percentage */}
                <text x={pos.x} y={pos.y + 5} textAnchor="middle" fill="#fff" fontSize="12" fontWeight="bold">
                  {filter.remainingLife.toFixed(0)}%
                </text>
              </g>
            );
          })}

          {/* Conditioned air output */}
          <g>
            <rect x="720" y="120" width="60" height="60" rx="8" fill="#1e293b" stroke="#475569" strokeWidth="2" />
            <text x="750" y="150" textAnchor="middle" fill="#64748b" fontSize="10">CABIN</text>
            <text x="750" y="163" textAnchor="middle" fill="#64748b" fontSize="10">AIR</text>
            
            <motion.path
              d="M770 150 L790 150"
              stroke="#10b981"
              strokeWidth="2"
              strokeLinecap="round"
              initial={{ opacity: 0.3 }}
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </g>

          {/* Connecting pipes */}
          <path
            d="M80 150 L115 150 M185 150 L265 150 M335 150 L415 150 M485 150 L565 150 M635 150 L720 150"
            stroke="#475569"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </svg>

        {/* Airflow indicator */}
        <div className="absolute bottom-4 left-4 bg-slate-800/80 rounded-lg px-3 py-2">
          <div className="flex items-center gap-2">
            <motion.div 
              className="w-2 h-2 rounded-full bg-cyan-400"
              animate={{ scale: [1, 1.5, 1] }}
              transition={{ duration: 1 / (airflowIntensity + 0.3), repeat: Infinity }}
            />
            <span className="text-slate-400 text-xs">Airflow: </span>
            <span className="text-white text-xs font-mono">{airflow.velocity.toFixed(1)} m/s</span>
          </div>
        </div>
      </div>

      {/* Selected filter details */}
      {selectedFilter && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 p-4 bg-slate-900/50 rounded-lg border border-slate-700/50"
        >
          {filters.filter(f => f.id === selectedFilter).map(filter => (
            <div key={filter.id}>
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-white font-semibold">{filter.name}</h4>
                <span className={`px-2 py-1 rounded text-xs font-semibold uppercase ${
                  filter.status === 'healthy' ? 'bg-emerald-500/20 text-emerald-400' :
                  filter.status === 'warning' ? 'bg-amber-500/20 text-amber-400' :
                  'bg-red-500/20 text-red-400'
                }`}>
                  {filter.status}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="text-slate-400 block">Operating Hours</span>
                  <span className="text-white font-mono">{filter.operatingHours.toFixed(0)}h</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Pressure Drop</span>
                  <span className="text-white font-mono">{filter.pressureDrop.toFixed(0)} Pa</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Efficiency</span>
                  <span className="text-white font-mono">{(filter.efficiency * 100).toFixed(2)}%</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Particle Loading</span>
                  <span className="text-white font-mono">{filter.particleLoadingPct.toFixed(1)}%</span>
                </div>
              </div>
            </div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
