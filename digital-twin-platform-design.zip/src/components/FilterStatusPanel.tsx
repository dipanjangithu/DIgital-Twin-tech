import { motion } from 'framer-motion';
import { Clock, Gauge, Activity, AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import type { FilterState } from '../types';

interface FilterStatusPanelProps {
  filters: FilterState[];
  onSelectFilter: (id: string) => void;
  selectedFilter: string | null;
}

export function FilterStatusPanel({ filters, onSelectFilter, selectedFilter }: FilterStatusPanelProps) {
  const getStatusIcon = (status: FilterState['status']) => {
    switch (status) {
      case 'healthy': return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'critical': return <XCircle className="w-4 h-4 text-red-400" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-600" />;
      default: return null;
    }
  };

  const getStatusBg = (status: FilterState['status']) => {
    switch (status) {
      case 'healthy': return 'border-emerald-500/30 hover:border-emerald-500/50';
      case 'warning': return 'border-amber-500/30 hover:border-amber-500/50';
      case 'critical': return 'border-red-500/30 hover:border-red-500/50 animate-pulse';
      case 'failed': return 'border-red-800/50 opacity-60';
      default: return 'border-slate-700';
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-4">
      <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
        <Activity className="w-5 h-5 text-cyan-400" />
        Filter Status Overview
      </h3>

      <div className="space-y-3">
        {filters.map((filter, index) => (
          <motion.div
            key={filter.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            onClick={() => onSelectFilter(filter.id)}
            className={`p-4 rounded-lg bg-slate-900/50 border cursor-pointer transition-all ${getStatusBg(filter.status)} ${
              selectedFilter === filter.id ? 'ring-2 ring-cyan-500/50' : ''
            }`}
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(filter.status)}
                  <h4 className="text-white font-medium text-sm">{filter.name}</h4>
                </div>
                <p className="text-slate-400 text-xs mt-0.5">{filter.location}</p>
              </div>
              <span className={`text-lg font-bold ${
                filter.remainingLife >= 60 ? 'text-emerald-400' :
                filter.remainingLife >= 30 ? 'text-amber-400' :
                'text-red-400'
              }`}>
                {filter.remainingLife.toFixed(0)}%
              </span>
            </div>

            {/* Progress bar */}
            <div className="mb-3">
              <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                <motion.div
                  className={`h-full rounded-full ${
                    filter.remainingLife >= 60 ? 'bg-gradient-to-r from-emerald-500 to-emerald-400' :
                    filter.remainingLife >= 30 ? 'bg-gradient-to-r from-amber-500 to-amber-400' :
                    'bg-gradient-to-r from-red-500 to-red-400'
                  }`}
                  initial={{ width: 0 }}
                  animate={{ width: `${filter.remainingLife}%` }}
                  transition={{ duration: 1, ease: 'easeOut' }}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3 h-3 text-slate-500" />
                <span className="text-slate-400">{filter.operatingHours.toFixed(0)}h</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Gauge className="w-3 h-3 text-slate-500" />
                <span className="text-slate-400">{filter.pressureDrop.toFixed(0)} Pa</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-slate-500">Eff:</span>
                <span className="text-slate-400">{(filter.efficiency * 100).toFixed(1)}%</span>
              </div>
            </div>

            {filter.status === 'critical' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-3 pt-3 border-t border-red-500/20"
              >
                <div className="flex items-center gap-2 text-xs text-red-400">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Maintenance required by {formatDate(filter.nextMaintenanceDate)}</span>
                </div>
              </motion.div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Summary stats */}
      <div className="mt-4 pt-4 border-t border-slate-700/50">
        <div className="grid grid-cols-4 gap-2 text-center">
          <div>
            <div className="text-emerald-400 font-bold text-lg">
              {filters.filter(f => f.status === 'healthy').length}
            </div>
            <div className="text-slate-400 text-xs">Healthy</div>
          </div>
          <div>
            <div className="text-amber-400 font-bold text-lg">
              {filters.filter(f => f.status === 'warning').length}
            </div>
            <div className="text-slate-400 text-xs">Warning</div>
          </div>
          <div>
            <div className="text-red-400 font-bold text-lg">
              {filters.filter(f => f.status === 'critical').length}
            </div>
            <div className="text-slate-400 text-xs">Critical</div>
          </div>
          <div>
            <div className="text-slate-400 font-bold text-lg">
              {filters.filter(f => f.status === 'failed').length}
            </div>
            <div className="text-slate-400 text-xs">Failed</div>
          </div>
        </div>
      </div>
    </div>
  );
}
