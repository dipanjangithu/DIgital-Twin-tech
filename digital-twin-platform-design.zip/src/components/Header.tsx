import { Activity, Bell, Settings, User, Wifi, WifiOff } from 'lucide-react';
import { useState, useEffect } from 'react';

interface HeaderProps {
  systemHealth: number;
  operatingMode: string;
  alertCount: number;
}

export function Header({ systemHealth, operatingMode, alertCount }: HeaderProps) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isConnected, setIsConnected] = useState(true);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    
    // Simulate occasional connection status changes
    const connectionCheck = setInterval(() => {
      setIsConnected(Math.random() > 0.05);
    }, 5000);

    return () => {
      clearInterval(timer);
      clearInterval(connectionCheck);
    };
  }, []);

  const getHealthColor = () => {
    if (systemHealth >= 70) return 'text-emerald-400';
    if (systemHealth >= 40) return 'text-amber-400';
    return 'text-red-400';
  };

  const getModeColor = () => {
    switch (operatingMode) {
      case 'normal': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case 'high-load': return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      case 'emergency': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'maintenance': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <header className="bg-slate-900/80 backdrop-blur-xl border-b border-slate-700/50 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full ${isConnected ? 'bg-emerald-500' : 'bg-red-500'} border-2 border-slate-900`} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">AeroTwin</h1>
              <p className="text-xs text-slate-400">Air Filtration Digital Twin</p>
            </div>
          </div>
          
          <div className="h-8 w-px bg-slate-700" />
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              {isConnected ? (
                <Wifi className="w-4 h-4 text-emerald-400" />
              ) : (
                <WifiOff className="w-4 h-4 text-red-400" />
              )}
              <span className={`text-sm ${isConnected ? 'text-emerald-400' : 'text-red-400'}`}>
                {isConnected ? 'Live Data' : 'Reconnecting...'}
              </span>
            </div>
            
            <div className={`px-3 py-1.5 rounded-lg border ${getModeColor()} text-xs font-semibold uppercase tracking-wide`}>
              {operatingMode.replace('-', ' ')}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-slate-400">System Health:</span>
            <span className={`font-bold text-lg ${getHealthColor()}`}>{systemHealth.toFixed(1)}%</span>
          </div>
          
          <div className="h-8 w-px bg-slate-700" />
          
          <div className="text-right">
            <div className="text-white font-mono text-sm">
              {currentTime.toLocaleTimeString('en-US', { hour12: false })}
            </div>
            <div className="text-slate-400 text-xs">
              {currentTime.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button className="relative p-2 rounded-lg hover:bg-slate-800 transition-colors">
              <Bell className="w-5 h-5 text-slate-400" />
              {alertCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold">
                  {alertCount > 9 ? '9+' : alertCount}
                </span>
              )}
            </button>
            <button className="p-2 rounded-lg hover:bg-slate-800 transition-colors">
              <Settings className="w-5 h-5 text-slate-400" />
            </button>
            <button className="p-2 rounded-lg hover:bg-slate-800 transition-colors">
              <User className="w-5 h-5 text-slate-400" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
