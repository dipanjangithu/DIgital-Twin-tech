import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Zap, 
  Wind, 
  Mountain, 
  Thermometer,
  Droplets,
  AlertTriangle,
  Filter
} from 'lucide-react';
import type { ScenarioType } from '../types';
import { SCENARIOS } from '../utils/physicsEngine';

interface SimulationControlProps {
  currentScenario: ScenarioType;
  onScenarioChange: (scenario: ScenarioType) => void;
  onReset: () => void;
  isRunning: boolean;
  onToggleRunning: () => void;
}

export function SimulationControl({ 
  currentScenario, 
  onScenarioChange, 
  onReset,
  isRunning,
  onToggleRunning
}: SimulationControlProps) {
  const [timeAcceleration, setTimeAcceleration] = useState(1);

  const getScenarioIcon = (id: ScenarioType) => {
    switch (id) {
      case 'normal': return <Wind className="w-4 h-4" />;
      case 'dust_storm': return <Zap className="w-4 h-4" />;
      case 'high_altitude': return <Mountain className="w-4 h-4" />;
      case 'rapid_descent': return <Zap className="w-4 h-4" />;
      case 'extreme_cold': return <Thermometer className="w-4 h-4" />;
      case 'extreme_hot': return <Thermometer className="w-4 h-4" />;
      case 'sensor_failure': return <AlertTriangle className="w-4 h-4" />;
      case 'filter_clog': return <Filter className="w-4 h-4" />;
      default: return <Wind className="w-4 h-4" />;
    }
  };

  const scenarioList = Object.values(SCENARIOS);

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-semibold">Simulation Control</h3>
            <p className="text-slate-400 text-xs">Physics-based scenario testing</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <motion.button
            onClick={onToggleRunning}
            whileTap={{ scale: 0.95 }}
            className={`p-2 rounded-lg transition-colors ${
              isRunning 
                ? 'bg-amber-500/20 text-amber-400 hover:bg-amber-500/30' 
                : 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30'
            }`}
          >
            {isRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          </motion.button>
          <motion.button
            onClick={onReset}
            whileTap={{ scale: 0.95 }}
            className="p-2 rounded-lg bg-slate-700/50 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <RotateCcw className="w-5 h-5" />
          </motion.button>
        </div>
      </div>

      {/* Time acceleration slider */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-slate-400 text-sm">Time Acceleration</span>
          <span className="text-white font-mono text-sm">{timeAcceleration}x</span>
        </div>
        <input
          type="range"
          min="1"
          max="100"
          value={timeAcceleration}
          onChange={(e) => setTimeAcceleration(Number(e.target.value))}
          className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
        />
        <div className="flex justify-between text-xs text-slate-500 mt-1">
          <span>Real-time</span>
          <span>100x</span>
        </div>
      </div>

      {/* Scenario selection */}
      <div className="mb-4">
        <span className="text-slate-400 text-sm block mb-3">Test Scenarios</span>
        <div className="grid grid-cols-2 gap-2">
          {scenarioList.map((scenario) => (
            <motion.button
              key={scenario.id}
              onClick={() => onScenarioChange(scenario.id)}
              whileTap={{ scale: 0.98 }}
              className={`p-3 rounded-lg border text-left transition-all ${
                currentScenario === scenario.id
                  ? 'bg-cyan-500/20 border-cyan-500/50 text-white'
                  : 'bg-slate-900/50 border-slate-700/50 text-slate-400 hover:border-slate-600 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                <span className="text-lg">{scenario.icon}</span>
                {getScenarioIcon(scenario.id)}
              </div>
              <div className="text-xs font-medium truncate">{scenario.name}</div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Current scenario details */}
      <motion.div
        key={currentScenario}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-slate-900/50 rounded-lg p-4 border border-slate-700/50"
      >
        <div className="flex items-center gap-2 mb-2">
          <span className="text-2xl">{SCENARIOS[currentScenario].icon}</span>
          <span className="text-white font-medium">{SCENARIOS[currentScenario].name}</span>
        </div>
        <p className="text-slate-400 text-xs mb-4">{SCENARIOS[currentScenario].description}</p>
        
        <div className="grid grid-cols-3 gap-3 text-xs">
          <div className="bg-slate-800/50 rounded p-2">
            <div className="flex items-center gap-1 text-slate-400 mb-1">
              <Mountain className="w-3 h-3" />
              Altitude
            </div>
            <div className="text-white font-mono">
              {SCENARIOS[currentScenario].parameters.altitude?.toLocaleString()} ft
            </div>
          </div>
          <div className="bg-slate-800/50 rounded p-2">
            <div className="flex items-center gap-1 text-slate-400 mb-1">
              <Thermometer className="w-3 h-3" />
              Temp
            </div>
            <div className="text-white font-mono">
              {SCENARIOS[currentScenario].parameters.temperature}°C
            </div>
          </div>
          <div className="bg-slate-800/50 rounded p-2">
            <div className="flex items-center gap-1 text-slate-400 mb-1">
              <Droplets className="w-3 h-3" />
              Humidity
            </div>
            <div className="text-white font-mono">
              {SCENARIOS[currentScenario].parameters.humidity}%
            </div>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t border-slate-700/50">
          <div className="text-slate-400 text-xs mb-2">Stress Multipliers</div>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Dust</span>
              <span className={`font-mono ${
                SCENARIOS[currentScenario].multipliers.dustLoading > 1 ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {SCENARIOS[currentScenario].multipliers.dustLoading}x
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Degradation</span>
              <span className={`font-mono ${
                SCENARIOS[currentScenario].multipliers.degradationRate > 1 ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {SCENARIOS[currentScenario].multipliers.degradationRate}x
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Resistance</span>
              <span className={`font-mono ${
                SCENARIOS[currentScenario].multipliers.airflowResistance > 1 ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {SCENARIOS[currentScenario].multipliers.airflowResistance}x
              </span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* What-if analysis hint */}
      <div className="mt-4 p-3 bg-gradient-to-r from-purple-500/10 to-indigo-500/10 rounded-lg border border-purple-500/20">
        <div className="flex items-center gap-2 text-purple-400 text-xs">
          <Zap className="w-4 h-4" />
          <span className="font-medium">What-If Analysis</span>
        </div>
        <p className="text-slate-400 text-xs mt-1">
          Select a scenario to simulate extreme conditions and predict system behavior.
          Compare results with live data to validate the digital twin accuracy.
        </p>
      </div>
    </div>
  );
}
