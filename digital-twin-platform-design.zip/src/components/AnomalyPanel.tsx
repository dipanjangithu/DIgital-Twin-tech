import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, CheckCircle, XCircle, Bell, Eye, EyeOff } from 'lucide-react';
import type { FilterState, Anomaly } from '../types';
import { detectAnomalies } from '../utils/mlModels';

interface AnomalyPanelProps {
  filters: FilterState[];
  onAnomalyCount: (count: number) => void;
}

export function AnomalyPanel({ filters, onAnomalyCount }: AnomalyPanelProps) {
  const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
  const [showAcknowledged, setShowAcknowledged] = useState(false);

  useEffect(() => {
    // Simulate baseline from historical data
    const baseline = {
      avgPressure: 250,
      avgParticulates: 15000
    };

    // Detect anomalies periodically
    const interval = setInterval(() => {
      const newAnomalies = detectAnomalies(filters, baseline);
      
      // Merge with existing anomalies, avoiding duplicates
      setAnomalies(prev => {
        const existingIds = prev.map(a => a.id);
        const uniqueNew = newAnomalies.filter(a => !existingIds.includes(a.id));
        const updated = [...prev, ...uniqueNew].slice(-20); // Keep last 20
        return updated;
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [filters]);

  useEffect(() => {
    const unacknowledgedCount = anomalies.filter(a => !a.isAcknowledged).length;
    onAnomalyCount(unacknowledgedCount);
  }, [anomalies, onAnomalyCount]);

  const acknowledgeAnomaly = (id: string) => {
    setAnomalies(prev => 
      prev.map(a => a.id === id ? { ...a, isAcknowledged: true } : a)
    );
  };

  const acknowledgeAll = () => {
    setAnomalies(prev => prev.map(a => ({ ...a, isAcknowledged: true })));
  };

  const getSeverityIcon = (severity: Anomaly['severity']) => {
    switch (severity) {
      case 'critical': return <XCircle className="w-4 h-4 text-red-400" />;
      case 'high': return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'medium': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'low': return <Bell className="w-4 h-4 text-blue-400" />;
      default: return null;
    }
  };

  const getSeverityBg = (severity: Anomaly['severity']) => {
    switch (severity) {
      case 'critical': return 'bg-red-500/10 border-red-500/30';
      case 'high': return 'bg-amber-500/10 border-amber-500/30';
      case 'medium': return 'bg-yellow-500/10 border-yellow-500/30';
      case 'low': return 'bg-blue-500/10 border-blue-500/30';
      default: return 'bg-slate-500/10 border-slate-500/30';
    }
  };

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const visibleAnomalies = showAcknowledged 
    ? anomalies 
    : anomalies.filter(a => !a.isAcknowledged);

  const unacknowledgedCount = anomalies.filter(a => !a.isAcknowledged).length;

  return (
    <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-amber-400" />
          <h3 className="text-white font-semibold">Anomaly Detection</h3>
          {unacknowledgedCount > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-xs font-bold">
              {unacknowledgedCount} new
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAcknowledged(!showAcknowledged)}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-white transition-colors"
          >
            {showAcknowledged ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
            {showAcknowledged ? 'Hide' : 'Show'} acknowledged
          </button>
          {unacknowledgedCount > 0 && (
            <button
              onClick={acknowledgeAll}
              className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              Acknowledge all
            </button>
          )}
        </div>
      </div>

      <div className="space-y-2 max-h-80 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent">
        <AnimatePresence>
          {visibleAnomalies.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-8 text-slate-400"
            >
              <CheckCircle className="w-10 h-10 mb-2 text-emerald-400/50" />
              <p className="text-sm">No active anomalies detected</p>
              <p className="text-xs mt-1">System operating within normal parameters</p>
            </motion.div>
          ) : (
            visibleAnomalies.map((anomaly, index) => (
              <motion.div
                key={anomaly.id}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: anomaly.isAcknowledged ? 0.5 : 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ delay: index * 0.05 }}
                className={`p-3 rounded-lg border ${getSeverityBg(anomaly.severity)} ${
                  anomaly.isAcknowledged ? 'opacity-50' : ''
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {getSeverityIcon(anomaly.severity)}
                    <span className="text-white text-sm font-medium">{anomaly.type}</span>
                  </div>
                  <span className="text-slate-400 text-xs">{formatTime(anomaly.timestamp)}</span>
                </div>
                
                <p className="text-slate-300 text-xs mb-2">{anomaly.description}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-slate-400">
                      Component: <span className="text-white">{anomaly.affectedComponent}</span>
                    </span>
                    <span className="text-slate-400">
                      Score: <span className="text-white">{(anomaly.score * 100).toFixed(0)}%</span>
                    </span>
                  </div>
                  
                  {!anomaly.isAcknowledged && (
                    <button
                      onClick={() => acknowledgeAnomaly(anomaly.id)}
                      className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
                    >
                      Acknowledge
                    </button>
                  )}
                </div>

                {anomaly.recommendedAction && (
                  <div className="mt-2 pt-2 border-t border-slate-700/50">
                    <p className="text-xs text-slate-400">
                      <span className="text-cyan-400">Recommended:</span> {anomaly.recommendedAction}
                    </p>
                  </div>
                )}
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {/* Anomaly score distribution */}
      <div className="mt-4 pt-4 border-t border-slate-700/50">
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="text-slate-400">Isolation Forest Score Distribution</span>
          <span className="text-slate-400">Last 24h</span>
        </div>
        <div className="flex gap-0.5 h-8 items-end">
          {[...Array(24)].map((_, i) => {
            const height = Math.random() * 100;
            const isAnomaly = height > 70;
            return (
              <div
                key={i}
                className={`flex-1 rounded-t ${isAnomaly ? 'bg-red-500/60' : 'bg-slate-600/40'}`}
                style={{ height: `${Math.max(10, height)}%` }}
              />
            );
          })}
        </div>
        <div className="flex justify-between text-xs text-slate-500 mt-1">
          <span>24h ago</span>
          <span>Now</span>
        </div>
      </div>
    </div>
  );
}
