// Core sensor data types
export interface SensorReading {
  timestamp: number;
  value: number;
  unit: string;
  quality: 'good' | 'degraded' | 'bad';
}

export interface AirflowData extends SensorReading {
  velocity: number; // m/s
  volumetricRate: number; // m³/s
}

export interface PressureData extends SensorReading {
  differential: number; // Pa
  upstream: number;
  downstream: number;
}

export interface ParticulateData extends SensorReading {
  pm1: number;
  pm25: number;
  pm10: number;
  totalCount: number; // particles/m³
}

export interface EnvironmentalData {
  temperature: number; // °C
  humidity: number; // %
  altitude: number; // ft
  ambientPressure: number; // kPa
}

// Filter system types
export interface FilterState {
  id: string;
  name: string;
  type: 'HEPA' | 'Carbon' | 'Pre-filter' | 'Recirculation';
  location: string;
  installDate: number;
  operatingHours: number;
  maxOperatingHours: number;
  pressureDrop: number;
  maxPressureDrop: number;
  particleLoadingPct: number;
  efficiency: number;
  status: 'healthy' | 'warning' | 'critical' | 'failed';
  remainingLife: number; // percentage
  nextMaintenanceDate: number;
}

export interface SystemState {
  timestamp: number;
  filters: FilterState[];
  airflow: AirflowData;
  pressure: PressureData;
  particulates: ParticulateData;
  environment: EnvironmentalData;
  systemHealth: number;
  operatingMode: 'normal' | 'high-load' | 'emergency' | 'maintenance';
}

// Physics simulation types
export interface PhysicsParams {
  filterArea: number; // m²
  filterThickness: number; // m
  permeability: number; // m²
  porosity: number;
  fiberDiameter: number; // μm
  dustLoadingRate: number; // g/m²/h
  particleDensity: number; // kg/m³
}

export interface SimulationState {
  isRunning: boolean;
  timeAcceleration: number;
  simulatedTime: number;
  scenario: ScenarioType;
  parameters: PhysicsParams;
}

export type ScenarioType = 
  | 'normal'
  | 'dust_storm'
  | 'high_altitude'
  | 'rapid_descent'
  | 'extreme_cold'
  | 'extreme_hot'
  | 'sensor_failure'
  | 'filter_clog';

export interface Scenario {
  id: ScenarioType;
  name: string;
  description: string;
  icon: string;
  parameters: Partial<EnvironmentalData>;
  multipliers: {
    dustLoading: number;
    degradationRate: number;
    airflowResistance: number;
  };
}

// ML/AI types
export interface Prediction {
  timestamp: number;
  type: 'rul' | 'anomaly' | 'failure' | 'optimization';
  filterId?: string;
  confidence: number;
  value: number;
  unit: string;
  explanation?: string[];
  featureImportance?: Record<string, number>;
}

export interface Anomaly {
  id: string;
  timestamp: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  type: string;
  description: string;
  affectedComponent: string;
  score: number;
  isAcknowledged: boolean;
  recommendedAction: string;
}

export interface MaintenanceRecommendation {
  id: string;
  filterId: string;
  type: 'replace' | 'inspect' | 'clean' | 'monitor';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  scheduledDate: number;
  estimatedCost: number;
  estimatedDowntime: number; // minutes
  reason: string;
  confidence: number;
}

// Dashboard types
export interface Alert {
  id: string;
  timestamp: number;
  severity: 'info' | 'warning' | 'error' | 'critical';
  title: string;
  message: string;
  source: string;
  isRead: boolean;
}

export interface MetricCard {
  label: string;
  value: number | string;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  trendValue: number;
  status: 'good' | 'warning' | 'critical';
}

export interface TimeSeriesPoint {
  timestamp: number;
  value: number;
  predicted?: number;
  lowerBound?: number;
  upperBound?: number;
}

export interface ChartData {
  label: string;
  data: TimeSeriesPoint[];
  color: string;
}
