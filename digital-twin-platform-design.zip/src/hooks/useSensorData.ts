import { useState, useEffect, useCallback, useRef } from 'react';
import type { 
  SystemState, 
  FilterState, 
  AirflowData, 
  PressureData, 
  ParticulateData,
  EnvironmentalData,
  TimeSeriesPoint,
  ScenarioType
} from '../types';
import { 
  calculatePressureDrop, 
  calculateFilterDegradation,
  calculateAltitudeEffects,
  DEFAULT_PHYSICS_PARAMS,
  SCENARIOS,
  KalmanFilter
} from '../utils/physicsEngine';

const INITIAL_FILTERS: FilterState[] = [
  {
    id: 'filter-1',
    name: 'HEPA Filter - Zone A',
    type: 'HEPA',
    location: 'Forward Cabin',
    installDate: Date.now() - 90 * 24 * 60 * 60 * 1000,
    operatingHours: 2160,
    maxOperatingHours: 5000,
    pressureDrop: 180,
    maxPressureDrop: 500,
    particleLoadingPct: 35,
    efficiency: 0.9997,
    status: 'healthy',
    remainingLife: 78,
    nextMaintenanceDate: Date.now() + 30 * 24 * 60 * 60 * 1000
  },
  {
    id: 'filter-2',
    name: 'HEPA Filter - Zone B',
    type: 'HEPA',
    location: 'Mid Cabin',
    installDate: Date.now() - 150 * 24 * 60 * 60 * 1000,
    operatingHours: 3600,
    maxOperatingHours: 5000,
    pressureDrop: 320,
    maxPressureDrop: 500,
    particleLoadingPct: 58,
    efficiency: 0.9985,
    status: 'warning',
    remainingLife: 42,
    nextMaintenanceDate: Date.now() + 14 * 24 * 60 * 60 * 1000
  },
  {
    id: 'filter-3',
    name: 'Carbon Filter',
    type: 'Carbon',
    location: 'Recirculation Unit',
    installDate: Date.now() - 60 * 24 * 60 * 60 * 1000,
    operatingHours: 1440,
    maxOperatingHours: 4000,
    pressureDrop: 95,
    maxPressureDrop: 300,
    particleLoadingPct: 28,
    efficiency: 0.92,
    status: 'healthy',
    remainingLife: 85,
    nextMaintenanceDate: Date.now() + 45 * 24 * 60 * 60 * 1000
  },
  {
    id: 'filter-4',
    name: 'Pre-Filter',
    type: 'Pre-filter',
    location: 'Bleed Air Intake',
    installDate: Date.now() - 200 * 24 * 60 * 60 * 1000,
    operatingHours: 4800,
    maxOperatingHours: 6000,
    pressureDrop: 420,
    maxPressureDrop: 500,
    particleLoadingPct: 82,
    efficiency: 0.75,
    status: 'critical',
    remainingLife: 18,
    nextMaintenanceDate: Date.now() + 2 * 24 * 60 * 60 * 1000
  },
  {
    id: 'filter-5',
    name: 'Recirculation Filter',
    type: 'Recirculation',
    location: 'Aft Cabin',
    installDate: Date.now() - 120 * 24 * 60 * 60 * 1000,
    operatingHours: 2880,
    maxOperatingHours: 5000,
    pressureDrop: 210,
    maxPressureDrop: 500,
    particleLoadingPct: 45,
    efficiency: 0.9990,
    status: 'healthy',
    remainingLife: 62,
    nextMaintenanceDate: Date.now() + 25 * 24 * 60 * 60 * 1000
  }
];

export function useSensorData(scenario: ScenarioType = 'normal') {
  const [systemState, setSystemState] = useState<SystemState | null>(null);
  const [timeSeriesData, setTimeSeriesData] = useState<{
    airflow: TimeSeriesPoint[];
    pressure: TimeSeriesPoint[];
    particulates: TimeSeriesPoint[];
    temperature: TimeSeriesPoint[];
    humidity: TimeSeriesPoint[];
  }>({
    airflow: [],
    pressure: [],
    particulates: [],
    temperature: [],
    humidity: []
  });
  
  const filtersRef = useRef<FilterState[]>([...INITIAL_FILTERS]);
  const kalmanFilters = useRef<Record<string, KalmanFilter>>({
    airflow: new KalmanFilter(8.5),
    pressure: new KalmanFilter(250),
    particulates: new KalmanFilter(15000),
    temperature: new KalmanFilter(22),
    humidity: new KalmanFilter(45)
  });

  const generateSensorData = useCallback(() => {
    const scenarioConfig = SCENARIOS[scenario];
    const multipliers = scenarioConfig.multipliers;
    const params = scenarioConfig.parameters;
    
    const altitudeEffects = calculateAltitudeEffects(params.altitude || 35000);
    
    // Generate airflow data with physics-based noise
    const baseAirflow = 8.5 * (altitudeEffects.density / 1.225);
    const airflowNoise = (Math.random() - 0.5) * 0.5 * multipliers.airflowResistance;
    const rawAirflow = baseAirflow + airflowNoise;
    const filteredAirflow = kalmanFilters.current.airflow.update(rawAirflow);
    
    const airflow: AirflowData = {
      timestamp: Date.now(),
      value: filteredAirflow,
      unit: 'm³/s',
      quality: Math.abs(airflowNoise) > 0.3 ? 'degraded' : 'good',
      velocity: filteredAirflow / 0.5, // Assuming 0.5 m² duct area
      volumetricRate: filteredAirflow
    };
    
    // Calculate pressure based on physics
    const dustLoading = 0.1 * multipliers.dustLoading;
    const basePressure = calculatePressureDrop(
      airflow.velocity,
      DEFAULT_PHYSICS_PARAMS,
      dustLoading
    );
    const pressureNoise = (Math.random() - 0.5) * 20;
    const rawPressure = basePressure + pressureNoise;
    const filteredPressure = kalmanFilters.current.pressure.update(rawPressure);
    
    const pressure: PressureData = {
      timestamp: Date.now(),
      value: filteredPressure,
      unit: 'Pa',
      quality: scenario === 'sensor_failure' ? 'bad' : 'good',
      differential: filteredPressure,
      upstream: 101325 + filteredPressure,
      downstream: 101325
    };
    
    // Generate particulate data
    const baseParticulates = 15000 * multipliers.dustLoading;
    const particulateNoise = (Math.random() - 0.5) * 5000;
    const rawParticulates = baseParticulates + particulateNoise;
    const filteredParticulates = kalmanFilters.current.particulates.update(rawParticulates);
    
    const particulates: ParticulateData = {
      timestamp: Date.now(),
      value: filteredParticulates,
      unit: 'particles/m³',
      quality: 'good',
      pm1: filteredParticulates * 0.1,
      pm25: filteredParticulates * 0.3,
      pm10: filteredParticulates * 0.6,
      totalCount: filteredParticulates
    };
    
    // Environmental data
    const baseTemp = params.temperature || 22;
    const tempNoise = (Math.random() - 0.5) * 2;
    const filteredTemp = kalmanFilters.current.temperature.update(baseTemp + tempNoise);
    
    const baseHumidity = params.humidity || 45;
    const humidityNoise = (Math.random() - 0.5) * 5;
    const filteredHumidity = kalmanFilters.current.humidity.update(baseHumidity + humidityNoise);
    
    const environment: EnvironmentalData = {
      temperature: filteredTemp,
      humidity: Math.max(5, Math.min(95, filteredHumidity)),
      altitude: params.altitude || 35000,
      ambientPressure: altitudeEffects.pressure
    };
    
    // Update filter states
    const updatedFilters = filtersRef.current.map(filter => {
      const degradation = calculateFilterDegradation(
        filter,
        filter.pressureDrop + (Math.random() - 0.3) * multipliers.degradationRate,
        filter.operatingHours + 0.01 * multipliers.degradationRate
      );
      
      return {
        ...filter,
        ...degradation,
        operatingHours: filter.operatingHours + 0.01 * multipliers.degradationRate
      };
    });
    
    filtersRef.current = updatedFilters;
    
    // Calculate system health
    const avgRemainingLife = updatedFilters.reduce((sum, f) => sum + f.remainingLife, 0) / updatedFilters.length;
    const criticalFilters = updatedFilters.filter(f => f.status === 'critical' || f.status === 'failed').length;
    const systemHealth = Math.max(0, avgRemainingLife - criticalFilters * 20);
    
    const newState: SystemState = {
      timestamp: Date.now(),
      filters: updatedFilters,
      airflow,
      pressure,
      particulates,
      environment,
      systemHealth,
      operatingMode: criticalFilters > 0 ? 'emergency' : 
                     scenario === 'dust_storm' || scenario === 'filter_clog' ? 'high-load' : 'normal'
    };
    
    setSystemState(newState);
    
    // Update time series
    setTimeSeriesData(prev => {
      const maxPoints = 60;
      const timestamp = Date.now();
      
      return {
        airflow: [...prev.airflow.slice(-maxPoints + 1), { timestamp, value: airflow.value }],
        pressure: [...prev.pressure.slice(-maxPoints + 1), { timestamp, value: pressure.differential }],
        particulates: [...prev.particulates.slice(-maxPoints + 1), { timestamp, value: particulates.totalCount }],
        temperature: [...prev.temperature.slice(-maxPoints + 1), { timestamp, value: environment.temperature }],
        humidity: [...prev.humidity.slice(-maxPoints + 1), { timestamp, value: environment.humidity }]
      };
    });
    
  }, [scenario]);

  useEffect(() => {
    // Initial data generation
    generateSensorData();
    
    // Set up interval for continuous updates
    const interval = setInterval(generateSensorData, 1000);
    
    return () => clearInterval(interval);
  }, [generateSensorData]);

  const resetFilters = useCallback(() => {
    filtersRef.current = [...INITIAL_FILTERS];
  }, []);

  return { systemState, timeSeriesData, resetFilters };
}
