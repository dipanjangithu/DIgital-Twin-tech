import type { FilterState, PhysicsParams, ScenarioType, Scenario } from '../types';

// Physical constants
const AIR_VISCOSITY = 1.81e-5; // Pa·s at 20°C
const AIR_DENSITY = 1.225; // kg/m³ at sea level
const GRAVITY = 9.81; // m/s²

// Darcy's Law: ΔP = (μ * L * v) / k
// where μ = viscosity, L = thickness, v = velocity, k = permeability
export function calculatePressureDrop(
  velocity: number, // m/s
  params: PhysicsParams,
  dustLoading: number // kg/m²
): number {
  const basePermeability = params.permeability;
  
  // Permeability decreases as dust accumulates (Carmen-Kozeny relation modified)
  const loadingFactor = 1 - Math.min(0.95, dustLoading / 0.5);
  const effectivePermeability = basePermeability * loadingFactor;
  
  // Darcy's pressure drop
  const darcyPressureDrop = (AIR_VISCOSITY * params.filterThickness * velocity) / effectivePermeability;
  
  // Inertial resistance (Forchheimer term for high velocities)
  const inertialFactor = 0.55 * (1 - params.porosity) / (params.porosity * params.porosity * params.porosity);
  const inertialPressureDrop = inertialFactor * AIR_DENSITY * velocity * velocity * params.filterThickness / Math.sqrt(effectivePermeability);
  
  return darcyPressureDrop + inertialPressureDrop;
}

// Filter efficiency using single fiber theory
export function calculateFilterEfficiency(
  particleDiameter: number, // μm
  velocity: number,
  params: PhysicsParams
): number {
  const dp = particleDiameter * 1e-6; // Convert to meters
  const df = params.fiberDiameter * 1e-6;
  
  // Stokes number (inertial impaction)
  const stk = (params.particleDensity * dp * dp * velocity) / (18 * AIR_VISCOSITY * df);
  
  // Interception parameter
  const R = dp / df;
  
  // Diffusion collection (Brownian motion)
  const Pe = (velocity * df) / (1.38e-23 * 293 / (3 * Math.PI * AIR_VISCOSITY * dp)); // Peclet number
  const diffusionEff = 2.6 * Math.pow(1 - params.porosity, 1/3) * Math.pow(Pe, -2/3);
  
  // Interception efficiency
  const interceptionEff = 0.6 * (1 - params.porosity) * R * R / (1 - params.porosity + R);
  
  // Inertial impaction efficiency
  const impactionEff = stk * stk / (stk * stk + 0.77 * stk + 0.22);
  
  // Combined single fiber efficiency
  const singleFiberEff = 1 - (1 - diffusionEff) * (1 - interceptionEff) * (1 - impactionEff);
  
  // Total filter efficiency
  const filterEfficiency = 1 - Math.exp(
    -4 * (1 - params.porosity) * singleFiberEff * params.filterThickness / (Math.PI * df)
  );
  
  return Math.min(0.9999, filterEfficiency);
}

// Particle accumulation model
export function calculateParticleAccumulation(
  currentLoading: number, // kg/m²
  particulateConc: number, // particles/m³
  velocity: number,
  efficiency: number,
  dt: number // seconds
): number {
  const avgParticleMass = 1e-12; // kg (assuming ~1μm particles)
  const capturedParticles = particulateConc * velocity * efficiency * dt;
  const massAccumulated = capturedParticles * avgParticleMass;
  
  return currentLoading + massAccumulated;
}

// Filter degradation model
export function calculateFilterDegradation(
  filter: FilterState,
  pressureDrop: number,
  operatingHours: number
): Partial<FilterState> {
  const pressureRatio = pressureDrop / filter.maxPressureDrop;
  const hoursRatio = operatingHours / filter.maxOperatingHours;
  
  // Combined degradation factor
  const degradation = Math.max(pressureRatio, hoursRatio);
  
  // Calculate remaining useful life
  const rul = Math.max(0, 100 * (1 - degradation));
  
  // Determine status based on degradation
  let status: FilterState['status'] = 'healthy';
  if (degradation > 0.95) status = 'failed';
  else if (degradation > 0.8) status = 'critical';
  else if (degradation > 0.6) status = 'warning';
  
  return {
    remainingLife: rul,
    status,
    pressureDrop,
    particleLoadingPct: Math.min(100, degradation * 100),
    efficiency: Math.max(0.5, 1 - degradation * 0.4) // Efficiency drops as filter degrades
  };
}

// Altitude effects on air properties
export function calculateAltitudeEffects(altitude: number): { density: number; viscosity: number; pressure: number } {
  // International Standard Atmosphere model
  const T0 = 288.15; // K
  const P0 = 101325; // Pa
  const L = 0.0065; // K/m lapse rate
  const R = 287.05; // J/(kg·K)
  const g = GRAVITY;
  
  const altitudeM = altitude * 0.3048; // Convert feet to meters
  
  const temperature = T0 - L * altitudeM;
  const pressure = P0 * Math.pow(temperature / T0, g / (R * L));
  const density = pressure / (R * temperature);
  const viscosity = AIR_VISCOSITY * Math.pow(temperature / T0, 0.76);
  
  return { density, viscosity, pressure: pressure / 1000 }; // kPa
}

// Scenario definitions
export const SCENARIOS: Record<ScenarioType, Scenario> = {
  normal: {
    id: 'normal',
    name: 'Normal Operations',
    description: 'Standard cruise conditions at 35,000 ft',
    icon: '✈️',
    parameters: { altitude: 35000, temperature: -54, humidity: 10 },
    multipliers: { dustLoading: 1, degradationRate: 1, airflowResistance: 1 }
  },
  dust_storm: {
    id: 'dust_storm',
    name: 'Dust Storm Conditions',
    description: 'High particulate load during ground operations in desert region',
    icon: '🌪️',
    parameters: { altitude: 0, temperature: 45, humidity: 15 },
    multipliers: { dustLoading: 15, degradationRate: 3, airflowResistance: 1.5 }
  },
  high_altitude: {
    id: 'high_altitude',
    name: 'High Altitude Cruise',
    description: 'Maximum cruise altitude with thin air',
    icon: '🏔️',
    parameters: { altitude: 43000, temperature: -65, humidity: 5 },
    multipliers: { dustLoading: 0.3, degradationRate: 0.8, airflowResistance: 0.6 }
  },
  rapid_descent: {
    id: 'rapid_descent',
    name: 'Rapid Descent',
    description: 'Emergency descent with rapid pressure changes',
    icon: '⬇️',
    parameters: { altitude: 10000, temperature: 5, humidity: 60 },
    multipliers: { dustLoading: 2, degradationRate: 2, airflowResistance: 1.8 }
  },
  extreme_cold: {
    id: 'extreme_cold',
    name: 'Extreme Cold',
    description: 'Arctic operations with ice crystal risk',
    icon: '❄️',
    parameters: { altitude: 30000, temperature: -70, humidity: 20 },
    multipliers: { dustLoading: 0.5, degradationRate: 1.2, airflowResistance: 1.3 }
  },
  extreme_hot: {
    id: 'extreme_hot',
    name: 'Extreme Heat',
    description: 'Ground operations in desert conditions',
    icon: '🔥',
    parameters: { altitude: 500, temperature: 55, humidity: 8 },
    multipliers: { dustLoading: 3, degradationRate: 1.5, airflowResistance: 1.1 }
  },
  sensor_failure: {
    id: 'sensor_failure',
    name: 'Sensor Failure',
    description: 'Simulated sensor malfunction scenario',
    icon: '⚠️',
    parameters: { altitude: 35000, temperature: -54, humidity: 10 },
    multipliers: { dustLoading: 1, degradationRate: 1, airflowResistance: 1 }
  },
  filter_clog: {
    id: 'filter_clog',
    name: 'Accelerated Clogging',
    description: 'Rapid filter clogging simulation',
    icon: '🚫',
    parameters: { altitude: 20000, temperature: -20, humidity: 40 },
    multipliers: { dustLoading: 10, degradationRate: 5, airflowResistance: 2 }
  }
};

// Default physics parameters for HEPA filter
export const DEFAULT_PHYSICS_PARAMS: PhysicsParams = {
  filterArea: 0.5, // m²
  filterThickness: 0.05, // m
  permeability: 5e-11, // m²
  porosity: 0.9,
  fiberDiameter: 2, // μm
  dustLoadingRate: 0.5, // g/m²/h
  particleDensity: 2500 // kg/m³
};

// Kalman filter for state estimation
export class KalmanFilter {
  private x: number; // State estimate
  private P: number; // Estimate covariance
  private Q: number; // Process noise covariance
  private R: number; // Measurement noise covariance

  constructor(initialValue: number, processNoise: number = 0.01, measurementNoise: number = 0.1) {
    this.x = initialValue;
    this.P = 1;
    this.Q = processNoise;
    this.R = measurementNoise;
  }

  update(measurement: number): number {
    // Prediction
    const xPred = this.x;
    const pPred = this.P + this.Q;

    // Update
    const K = pPred / (pPred + this.R);
    this.x = xPred + K * (measurement - xPred);
    this.P = (1 - K) * pPred;

    return this.x;
  }

  getState(): number {
    return this.x;
  }
}
