import type { FilterState, Prediction, Anomaly, MaintenanceRecommendation } from '../types';

// Simulated LSTM-based RUL prediction
export function predictRemainingUsefulLife(filter: FilterState): Prediction {
  const baseRUL = filter.remainingLife;
  
  // Simulate temporal pattern recognition
  const trend = Math.sin(Date.now() / 100000) * 2; // Slight oscillation
  const noise = (Math.random() - 0.5) * 3;
  
  // Calculate confidence based on data quality
  const confidence = 0.85 + Math.random() * 0.1;
  
  // Feature importance (simulated SHAP values)
  const featureImportance = {
    'Operating Hours': 0.35,
    'Pressure Drop': 0.28,
    'Particle Loading': 0.18,
    'Temperature Cycles': 0.12,
    'Humidity Exposure': 0.07
  };

  return {
    timestamp: Date.now(),
    type: 'rul',
    filterId: filter.id,
    confidence,
    value: Math.max(0, Math.min(100, baseRUL + trend + noise)),
    unit: '%',
    explanation: generateRULExplanation(filter),
    featureImportance
  };
}

function generateRULExplanation(filter: FilterState): string[] {
  const explanations: string[] = [];
  
  if (filter.pressureDrop > filter.maxPressureDrop * 0.7) {
    explanations.push('High pressure drop indicates significant particle loading');
  }
  if (filter.operatingHours > filter.maxOperatingHours * 0.6) {
    explanations.push('Operating hours approaching recommended replacement interval');
  }
  if (filter.efficiency < 0.95) {
    explanations.push('Reduced filtration efficiency detected');
  }
  if (filter.status === 'warning' || filter.status === 'critical') {
    explanations.push('Multiple degradation indicators present');
  }
  
  if (explanations.length === 0) {
    explanations.push('Filter operating within normal parameters');
  }
  
  return explanations;
}

// Anomaly detection using simulated Isolation Forest
export function detectAnomalies(
  filters: FilterState[],
  historicalBaseline: { avgPressure: number; avgParticulates: number }
): Anomaly[] {
  const anomalies: Anomaly[] = [];
  
  filters.forEach(filter => {
    // Pressure anomaly detection
    const pressureDeviation = Math.abs(filter.pressureDrop - historicalBaseline.avgPressure) / historicalBaseline.avgPressure;
    if (pressureDeviation > 0.3) {
      anomalies.push({
        id: `anomaly-${filter.id}-pressure-${Date.now()}`,
        timestamp: Date.now(),
        severity: pressureDeviation > 0.5 ? 'high' : 'medium',
        type: 'Pressure Deviation',
        description: `Pressure drop ${pressureDeviation > 0 ? 'above' : 'below'} baseline by ${(pressureDeviation * 100).toFixed(1)}%`,
        affectedComponent: filter.name,
        score: Math.min(1, pressureDeviation),
        isAcknowledged: false,
        recommendedAction: pressureDeviation > 0.5 
          ? 'Immediate inspection recommended' 
          : 'Schedule inspection within 24 hours'
      });
    }
    
    // Rapid degradation detection
    if (filter.status === 'critical' && filter.remainingLife > 20) {
      anomalies.push({
        id: `anomaly-${filter.id}-degradation-${Date.now()}`,
        timestamp: Date.now(),
        severity: 'critical',
        type: 'Accelerated Degradation',
        description: 'Filter showing abnormal degradation pattern',
        affectedComponent: filter.name,
        score: 0.85,
        isAcknowledged: false,
        recommendedAction: 'Investigate environmental factors and consider early replacement'
      });
    }
  });
  
  return anomalies;
}

// Random Forest failure classification
export function classifyFailureRisk(filter: FilterState): {
  failureProb: number;
  failureType: string;
  confidence: number;
} {
  // Feature extraction
  const features = {
    pressureRatio: filter.pressureDrop / filter.maxPressureDrop,
    hoursRatio: filter.operatingHours / filter.maxOperatingHours,
    efficiencyDrop: 1 - filter.efficiency,
    loadingRatio: filter.particleLoadingPct / 100
  };
  
  // Simulated ensemble prediction
  const failureProb = Math.pow(
    (features.pressureRatio * 0.4 + 
     features.hoursRatio * 0.3 + 
     features.efficiencyDrop * 0.2 + 
     features.loadingRatio * 0.1), 
    1.5
  ) * 100;
  
  // Classify failure type
  let failureType = 'Normal Wear';
  if (features.pressureRatio > features.hoursRatio * 1.5) {
    failureType = 'Excessive Loading';
  } else if (features.efficiencyDrop > 0.1) {
    failureType = 'Media Degradation';
  } else if (features.loadingRatio > 0.9) {
    failureType = 'Clogging';
  }
  
  return {
    failureProb: Math.min(95, failureProb),
    failureType,
    confidence: 0.78 + Math.random() * 0.15
  };
}

// Optimization recommendations
export function generateMaintenanceRecommendations(
  filters: FilterState[]
): MaintenanceRecommendation[] {
  const recommendations: MaintenanceRecommendation[] = [];
  
  filters.forEach(filter => {
    const failureRisk = classifyFailureRisk(filter);
    
    if (filter.status === 'critical' || failureRisk.failureProb > 70) {
      recommendations.push({
        id: `rec-${filter.id}-replace`,
        filterId: filter.id,
        type: 'replace',
        priority: 'urgent',
        scheduledDate: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
        estimatedCost: 2500,
        estimatedDowntime: 45,
        reason: `Critical status - ${failureRisk.failureType} detected`,
        confidence: failureRisk.confidence
      });
    } else if (filter.status === 'warning' || failureRisk.failureProb > 40) {
      recommendations.push({
        id: `rec-${filter.id}-inspect`,
        filterId: filter.id,
        type: 'inspect',
        priority: 'high',
        scheduledDate: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
        estimatedCost: 500,
        estimatedDowntime: 30,
        reason: `Warning indicators present - ${failureRisk.failureType}`,
        confidence: failureRisk.confidence
      });
    } else if (filter.remainingLife < 30) {
      recommendations.push({
        id: `rec-${filter.id}-schedule`,
        filterId: filter.id,
        type: 'replace',
        priority: 'medium',
        scheduledDate: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days
        estimatedCost: 2500,
        estimatedDowntime: 45,
        reason: 'Approaching end of service life',
        confidence: 0.9
      });
    } else if (filter.particleLoadingPct > 50) {
      recommendations.push({
        id: `rec-${filter.id}-clean`,
        filterId: filter.id,
        type: 'clean',
        priority: 'low',
        scheduledDate: Date.now() + 14 * 24 * 60 * 60 * 1000, // 14 days
        estimatedCost: 150,
        estimatedDowntime: 20,
        reason: 'Routine maintenance - particle loading at 50%+',
        confidence: 0.85
      });
    }
  });
  
  return recommendations.sort((a, b) => {
    const priorityOrder = { urgent: 0, high: 1, medium: 2, low: 3 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });
}

// Cost optimization model
export function optimizeMaintenanceSchedule(
  recommendations: MaintenanceRecommendation[]
): {
  totalCost: number;
  totalDowntime: number;
  optimizedCost: number;
  savings: number;
  batchedOperations: number;
} {
  const totalCost = recommendations.reduce((sum, r) => sum + r.estimatedCost, 0);
  const totalDowntime = recommendations.reduce((sum, r) => sum + r.estimatedDowntime, 0);
  
  // Simulate batching optimization
  const batchableCount = recommendations.filter(r => 
    r.priority !== 'urgent' && r.type !== 'replace'
  ).length;
  
  const batchSavings = batchableCount > 1 ? batchableCount * 100 : 0; // Labor savings from batching
  const downtimeSavings = batchableCount > 1 ? batchableCount * 10 : 0; // Reduced downtime from batching
  
  return {
    totalCost,
    totalDowntime: totalDowntime - downtimeSavings,
    optimizedCost: totalCost - batchSavings,
    savings: batchSavings,
    batchedOperations: Math.max(0, batchableCount - 1)
  };
}
